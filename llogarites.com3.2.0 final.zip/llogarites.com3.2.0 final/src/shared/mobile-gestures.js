(()=>{
  const coarsePointerMedia=window.matchMedia("(pointer: coarse)");
  let lastTouchEnd=0;

  function isInteractiveTarget(target){
    return Boolean(
      target &&
      typeof target.closest==="function" &&
      target.closest('a,button,input,select,textarea,label,summary,[role="button"],[contenteditable="true"]')
    );
  }

  document.addEventListener("touchend",(event)=>{
    if(!coarsePointerMedia.matches) return;
    const now=Date.now();
    const delta=now-lastTouchEnd;
    lastTouchEnd=now;

    if(delta<50||delta>320) return;
    if(event.touches&&event.touches.length>0) return;
    if(isInteractiveTarget(event.target)) return;

    event.preventDefault();
  },{passive:false});

})();
