(function(){
  if(window.lucide && typeof window.lucide.createIcons==="function") return;

  var icons={
    "apple":[
      '<path d="M12 20.9c-1 .9-2.1.9-3.2.5-1.1-.4-2-1.5-2.7-3.1-1.4-3.2-.9-6.7 1.1-8.2 1-.8 2.2-1 3.5-.3.7.3 1.3.3 2 0 1.1-.6 2.3-.5 3.3.1-.9.5-1.5 1.4-1.5 2.5 0 1.3.8 2.3 2 2.7-.3 1.2-.8 2.4-1.5 3.6-.8 1.4-1.8 2.4-3 2.2Z"/>',
      '<path d="M13 7.2c.6-.7 1-1.7.9-2.7-.9.1-1.8.6-2.4 1.3-.6.7-1 1.6-.9 2.5 .9 .1 1.8 -.4 2.4 -1.1Z"/>'
    ],
    "banknote":[
      '<rect width="20" height="12" x="2" y="6" rx="2"/>',
      '<circle cx="12" cy="12" r="2"/>',
      '<path d="M6 12h.01M18 12h.01"/>'
    ],
    "calculator":[
      '<rect width="16" height="20" x="4" y="2" rx="2"/>',
      '<line x1="8" x2="16" y1="6" y2="6"/>',
      '<line x1="16" x2="16" y1="14" y2="18"/>',
      '<path d="M8 10h.01M12 10h.01M16 10h.01M8 14h.01M12 14h.01M8 18h.01M12 18h.01"/>'
    ],
    "check":[
      '<path d="M20 6 9 17l-5-5"/>'
    ],
    "download":[
      '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>',
      '<polyline points="7 10 12 15 17 10"/>',
      '<line x1="12" x2="12" y1="15" y2="3"/>'
    ],
    "lock":[
      '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>',
      '<path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
    ],
    "menu":[
      '<line x1="4" x2="20" y1="12" y2="12"/>',
      '<line x1="4" x2="20" y1="6" y2="6"/>',
      '<line x1="4" x2="20" y1="18" y2="18"/>'
    ],
    "refresh-cw":[
      '<path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/>',
      '<path d="M3 3v5h5"/>',
      '<path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/>',
      '<path d="M16 16h5v5"/>'
    ],
    "share-2":[
      '<circle cx="18" cy="5" r="3"/>',
      '<circle cx="6" cy="12" r="3"/>',
      '<circle cx="18" cy="19" r="3"/>',
      '<line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/>',
      '<line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>'
    ],
    "smartphone":[
      '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>',
      '<path d="M12 18h.01"/>'
    ]
  };

  function toSvg(name, source){
    var svg=document.createElementNS("http://www.w3.org/2000/svg","svg");
    svg.setAttribute("xmlns","http://www.w3.org/2000/svg");
    svg.setAttribute("width","24");
    svg.setAttribute("height","24");
    svg.setAttribute("viewBox","0 0 24 24");
    svg.setAttribute("fill","none");
    svg.setAttribute("stroke","currentColor");
    svg.setAttribute("stroke-width","2");
    svg.setAttribute("stroke-linecap","round");
    svg.setAttribute("stroke-linejoin","round");
    svg.setAttribute("aria-hidden","true");
    svg.className="lucide lucide-"+name;
    if(source && source.className){
      svg.className+=" "+source.className;
    }
    svg.innerHTML=icons[name].join("");
    return svg;
  }

  function createIcons(){
    document.querySelectorAll("[data-lucide]").forEach(function(node){
      var name=node.getAttribute("data-lucide");
      if(!icons[name] || node.tagName.toLowerCase()==="svg") return;
      node.replaceWith(toSvg(name,node));
    });
  }

  window.lucide={createIcons:createIcons};
})();
