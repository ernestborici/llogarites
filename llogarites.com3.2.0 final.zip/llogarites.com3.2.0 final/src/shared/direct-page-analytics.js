(()=>{
  try{
    if(window.top !== window.self) return;
  }catch(_){
    return;
  }

  const analytics = window.LlogaritesAnalytics;
  if(!analytics || !analytics.configured || typeof analytics.trackVirtualPage !== "function") return;

  function trackCurrentPage(){
    let canonicalUrl = null;
    const canonicalEl = document.querySelector('link[rel="canonical"]');
    if(canonicalEl && canonicalEl.href){
      canonicalUrl = canonicalEl.href;
    }

    try{
      const resolved = new URL(canonicalUrl || window.location.href, window.location.href);
      analytics.trackVirtualPage({
        page_title: document.title,
        page_path: resolved.pathname || window.location.pathname || "/",
        page_location: resolved.href
      });
    }catch(_){
      analytics.trackVirtualPage({
        page_title: document.title,
        page_path: window.location.pathname || "/",
        page_location: window.location.href
      });
    }
  }

  trackCurrentPage();
  window.addEventListener("llogarites:analytics-ready", trackCurrentPage);
})();
