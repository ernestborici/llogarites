(function(){
const THEME_KEY="llogarites-theme";
const LIGHT_THEME_COLOR="#f5f5f7";
const DARK_THEME_COLOR="#1b2432";

function getTheme(){
  try{
    return localStorage.getItem(THEME_KEY)==="dark" ? "dark" : "light";
  }catch(_){
    return document.documentElement.classList.contains("theme-dark") ? "dark" : "light";
  }
}

function updateMetaTheme(theme){
  const meta=document.querySelector('meta[name="theme-color"]');
  if(meta){
    meta.setAttribute("content",theme==="dark" ? DARK_THEME_COLOR : LIGHT_THEME_COLOR);
  }
}

function updateToggles(scope){
  const root=scope||document;
  const isDark=getTheme()==="dark";
  root.querySelectorAll("[data-theme-toggle]").forEach((toggle)=>{
    toggle.setAttribute("role","switch");
    toggle.setAttribute("aria-checked",String(isDark));
    toggle.dataset.theme=isDark ? "dark" : "light";
  });
}

function syncEmbeddedThemes(theme, frame){
  const frames=frame ? [frame] : Array.from(document.querySelectorAll("iframe"));
  frames.forEach((iframe)=>{
    const applyToFrame=()=>{
      try{
        const frameDocument=iframe.contentWindow && iframe.contentWindow.document;
        if(!frameDocument) return;
        frameDocument.documentElement.classList.toggle("theme-dark",theme==="dark");
        const frameMeta=frameDocument.querySelector('meta[name="theme-color"]');
        if(frameMeta){
          frameMeta.setAttribute("content",theme==="dark" ? DARK_THEME_COLOR : LIGHT_THEME_COLOR);
        }
        if(iframe.contentWindow.LlogaritesTheme && typeof iframe.contentWindow.LlogaritesTheme.updateToggles==="function"){
          iframe.contentWindow.LlogaritesTheme.updateToggles(frameDocument);
        }
      }catch(_){}
    };

    iframe.addEventListener("load",applyToFrame,{once:true});

    try{
      if(iframe.contentDocument && iframe.contentDocument.readyState!=="loading"){
        applyToFrame();
      }
    }catch(_){}
  });
}

function applyTheme(theme){
  const nextTheme=theme==="dark" ? "dark" : "light";
  document.documentElement.classList.toggle("theme-dark",nextTheme==="dark");
  updateMetaTheme(nextTheme);
  updateToggles();
  syncEmbeddedThemes(nextTheme);
}

function setTheme(theme){
  const nextTheme=theme==="dark" ? "dark" : "light";
  try{
    localStorage.setItem(THEME_KEY,nextTheme);
  }catch(_){}
  applyTheme(nextTheme);
  try{
    if(window.top && window.top!==window && window.top.LlogaritesTheme && typeof window.top.LlogaritesTheme.applyTheme==="function"){
      window.top.LlogaritesTheme.applyTheme(nextTheme);
    }
  }catch(_){}
}

function toggleTheme(){
  setTheme(getTheme()==="dark" ? "light" : "dark");
}

function mountToggles(scope){
  const root=scope||document;
  root.querySelectorAll("[data-theme-toggle]").forEach((toggle)=>{
    if(toggle.dataset.themeBound==="1") return;
    toggle.dataset.themeBound="1";
    toggle.setAttribute("type",toggle.getAttribute("type")||"button");
    toggle.addEventListener("click",toggleTheme);
  });
  updateToggles(root);
}

window.addEventListener("storage",(event)=>{
  if(event.key===THEME_KEY){
    applyTheme(getTheme());
  }
});

document.addEventListener("DOMContentLoaded",()=>{
  mountToggles();
  applyTheme(getTheme());
});

window.LlogaritesTheme={
  applyTheme,
  getTheme,
  mountToggles,
  setTheme,
  syncEmbeddedThemes,
  toggleTheme,
  updateToggles
};

applyTheme(getTheme());
})();
