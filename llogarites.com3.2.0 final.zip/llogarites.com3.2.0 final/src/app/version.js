(function(){
  var appVersion="3.2.0";
  var appVersionKey="llogarites-app-version";
  var reloadKey="llogarites-reloaded-"+appVersion;
  window.__LLOGARITES_APP_VERSION__=appVersion;
  if(document.documentElement){
    document.documentElement.setAttribute("data-ui-version",appVersion);
  }

  async function ensureFreshVersion(){
    var previousVersion=null;
    try{
      previousVersion=localStorage.getItem(appVersionKey);
      localStorage.setItem(appVersionKey,appVersion);
    }catch(_){}

    if(previousVersion===appVersion || previousVersion===null) return;

    if("serviceWorker" in navigator){
      try{
        var registrations=await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(function(registration){
          return registration.update();
        }));
      }catch(_){}
    }

    try{
      if(sessionStorage.getItem(reloadKey)==="1") return;
      sessionStorage.setItem(reloadKey,"1");
    }catch(_){}

    window.location.reload();
  }

  function initServiceWorker(){
    if(!("serviceWorker" in navigator)) return;
    if(window.__LLOGARITES_SW_MANAGED__) return;
    window.__LLOGARITES_SW_MANAGED__=true;

    var didReloadForController=false;
    navigator.serviceWorker.addEventListener("controllerchange",function(){
      if(didReloadForController) return;
      didReloadForController=true;
      window.location.reload();
    });

    window.addEventListener("load",async function(){
      try{
        var registration=await navigator.serviceWorker.register("/service-worker.js",{updateViaCache:"none"});
        await registration.update();

        if(registration.waiting){
          registration.waiting.postMessage({type:"SKIP_WAITING"});
        }

        registration.addEventListener("updatefound",function(){
          var worker=registration.installing;
          if(!worker) return;
          worker.addEventListener("statechange",function(){
            if(worker.state==="installed" && navigator.serviceWorker.controller){
              worker.postMessage({type:"SKIP_WAITING"});
            }
          });
        });
      }catch(_){}
    },{once:true});
  }

  ensureFreshVersion().catch(function(){});
  initServiceWorker();

  document.addEventListener("DOMContentLoaded",function(){
    if(document.body){
      document.body.setAttribute("data-ui-version",appVersion);
    }
    var versionNodes=document.querySelectorAll("[data-app-version]");
    versionNodes.forEach(function(node){
      node.textContent=appVersion;
    });
  },{once:true});
})();
