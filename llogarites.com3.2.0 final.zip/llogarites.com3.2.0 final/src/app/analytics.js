(function(){
  const measurementId = String(window.LLOGARITES_ANALYTICS_ID || "").trim();
  const storageKey = "llogarites-analytics-consent";
  const accepted = "accepted";
  const rejected = "rejected";
  const eventQueue = [];
  let loaded = false;
  let banner = null;

  function readConsent(){
    try{
      return localStorage.getItem(storageKey);
    }catch(_){
      return null;
    }
  }

  function writeConsent(value){
    try{
      localStorage.setItem(storageKey, value);
    }catch(_){}
  }

  function dispatchAnalyticsEvent(name, detail){
    try{
      window.dispatchEvent(new CustomEvent(name, { detail: detail || {} }));
    }catch(_){}
  }

  function inTopWindow(){
    try{
      return window.top === window.self;
    }catch(_){
      return true;
    }
  }

  function ensureBannerStyles(){
    if(document.getElementById("analytics-consent-styles")) return;
    const style = document.createElement("style");
    style.id = "analytics-consent-styles";
    style.textContent = `
      .analytics-consent{
        position:fixed;
        right:18px;
        bottom:calc(18px + env(safe-area-inset-bottom, 0px));
        width:min(360px, calc(100vw - 36px));
        background:rgba(255,255,255,0.94);
        color:#111827;
        border-radius:14px;
        box-shadow:0 18px 44px rgba(15,23,42,0.18);
        padding:14px;
        z-index:9999;
        border:1px solid rgba(148,163,184,0.22);
        -webkit-backdrop-filter:saturate(180%) blur(18px);
        backdrop-filter:saturate(180%) blur(18px);
      }
      .analytics-consent h2{
        margin:0 0 5px 0;
        font-size:0.92rem;
        font-weight:750;
        line-height:1.25;
      }
      .analytics-consent p{
        margin:0;
        font-size:0.78rem;
        line-height:1.45;
        color:#4b5563;
      }
      .analytics-consent a{
        color:#090979;
        font-weight:650;
        text-underline-offset:2px;
      }
      .analytics-consent-actions{
        display:flex;
        gap:8px;
        flex-wrap:wrap;
        margin-top:12px;
      }
      .analytics-consent-btn{
        border:none;
        border-radius:11px;
        min-height:42px;
        padding:0 14px;
        font-size:0.84rem;
        font-weight:700;
        cursor:pointer;
        touch-action:manipulation;
      }
      .analytics-consent-btn.primary{
        background:#090979;
        color:#ffffff;
      }
      .analytics-consent-btn.secondary{
        background:#F1F3F8;
        color:#111827;
      }
      .analytics-consent-btn:focus-visible{
        outline:2px solid rgba(9,9,121,0.30);
        outline-offset:2px;
      }
      @media (max-width:720px){
        .analytics-consent{
          left:12px;
          right:12px;
          bottom:calc(12px + env(safe-area-inset-bottom, 0px));
          width:auto;
          padding:12px;
        }
        .analytics-consent-actions{
          display:grid;
          grid-template-columns:1fr 1fr;
        }
      }
    `;
    document.head.appendChild(style);
  }

  function hideBanner(){
    if(!banner) return;
    banner.remove();
    banner = null;
  }

  function applyConsent(value){
    const previous = readConsent();
    writeConsent(value);
    hideBanner();
    if(value === accepted){
      loadAnalytics();
      if(previous !== accepted){
        dispatchAnalyticsEvent("llogarites:analytics-ready", { consent: value });
      }
    }else{
      eventQueue.length = 0;
    }
    dispatchAnalyticsEvent("llogarites:analytics-consent-changed", { consent: value });
  }

  function showBanner(){
    if(!measurementId || !inTopWindow() || readConsent()) return;
    ensureBannerStyles();
    banner = document.createElement("div");
    banner.className = "analytics-consent";
    banner.setAttribute("role", "dialog");
    banner.setAttribute("aria-live", "polite");
    banner.innerHTML = `
      <h2>Anonymous usage measurement</h2>
      <p>
        Google Analytics is enabled only if you accept. The data helps us understand which pages are used most.
        Read more in <a href="/Privacy" target="_blank" rel="noopener">Privacy</a>.
      </p>
      <div class="analytics-consent-actions">
        <button type="button" class="analytics-consent-btn primary" data-consent="accept">Accept</button>
        <button type="button" class="analytics-consent-btn secondary" data-consent="reject">Not now</button>
      </div>
    `;
    banner.querySelector('[data-consent="accept"]').addEventListener("click", function(){
      applyConsent(accepted);
    });
    banner.querySelector('[data-consent="reject"]').addEventListener("click", function(){
      applyConsent(rejected);
    });
    document.body.appendChild(banner);
  }

  function scheduleBanner(){
    window.setTimeout(function(){
      if(typeof window.requestIdleCallback === "function"){
        window.requestIdleCallback(showBanner, { timeout: 1800 });
        return;
      }
      showBanner();
    }, 2500);
  }

  function enqueue(method, name, params){
    if(readConsent() !== accepted) return;
    if(loaded && typeof window.gtag === "function"){
      window.gtag(method, name, params);
      return;
    }
    eventQueue.push([method, name, params]);
  }

  function flushQueue(){
    if(!loaded || typeof window.gtag !== "function") return;
    while(eventQueue.length){
      const [method, name, params] = eventQueue.shift();
      window.gtag(method, name, params);
    }
  }

  function loadAnalytics(){
    if(!measurementId || loaded) return;
    loaded = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function(){
      window.dataLayer.push(arguments);
    };
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(measurementId);
    document.head.appendChild(script);
    window.gtag("js", new Date());
    window.gtag("config", measurementId, {
      anonymize_ip: true,
      send_page_view: false
    });
    flushQueue();
  }

  window.LlogaritesAnalytics = {
    configured: Boolean(measurementId),
    getConsent: readConsent,
    setConsent: applyConsent,
    trackVirtualPage: function(details){
      const payload = Object.assign({
        page_title: document.title,
        page_path: window.location.pathname || "/",
        page_location: window.location.href
      }, details || {});
      enqueue("event", "page_view", payload);
    },
    trackEvent: function(name, params){
      if(!name) return;
      enqueue("event", name, params || {});
    }
  };

  if(inTopWindow()){
    if(readConsent() === accepted){
      loadAnalytics();
    }else if(document.readyState === "loading"){
      document.addEventListener("DOMContentLoaded", scheduleBanner, { once:true });
    }else{
      scheduleBanner();
    }
  }
})();
