(function(){
  const PAGE_FILE_NAMES = {
    Kredia: "kredia",
    Paga: "paga",
    About: "about",
    FAQ: "faq",
    Privacy: "privacy"
  };

  const VIRTUAL_PAGES = {
    home: { path: "/", title: "Llogarites Kredie" },
    paga: { path: "/paga", title: "Llogarites Paga" },
    "about-install": { path: "/about-install", title: "Install" },
    about: { path: "/about", title: "About" },
    faq: { path: "/faq", title: "FAQ" },
    privacy: { path: "/privacy", title: "Privacy" },
    terms: { path: "/terms", title: "Terms" }
  };

  function isLocalRuntime(){
    const host = window.location.hostname;
    return window.location.protocol === "file:" || host === "localhost" || host === "127.0.0.1";
  }

  function isFileRuntime(){
    return window.location.protocol === "file:";
  }

  function fileBaseFor(baseName){
    return PAGE_FILE_NAMES[baseName] || baseName;
  }

  function linkPagePath(baseName){
    if(baseName === "Kredia"){
      return isFileRuntime() ? "./index.html" : "/";
    }
    const fileBase = fileBaseFor(baseName);
    return isLocalRuntime() ? `./${fileBase}.html` : `/${fileBase}`;
  }

  function shellPagePath(baseName, params, version){
    const local = isLocalRuntime();
    const fileBase = fileBaseFor(baseName);
    const pathName = baseName === "Kredia"
      ? (isFileRuntime() ? "index.html" : "/")
      : (local ? `${fileBase}.html` : `/${fileBase}`);
    const baseUrl = local ? window.location.href : window.location.origin;
    const url = new URL(pathName, baseUrl);

    if(local && version && version !== "auto" && url.pathname !== "/"){
      url.searchParams.set("v", version);
    }

    if(params){
      Object.entries(params).forEach(([key, value]) => {
        if(value !== null && value !== undefined && value !== ""){
          url.searchParams.set(key, String(value));
        }
      });
    }

    return `${url.pathname}${url.search}`;
  }

  function withVersion(href, version){
    if(!version || version === "auto") return href;

    try{
      const url = new URL(href, window.location.href);
      if(!isLocalRuntime()){
        return url.origin === window.location.origin
          ? url.pathname + url.search + url.hash
          : url.href;
      }
      if(url.origin === window.location.origin && (url.pathname === "/" || url.pathname === "/index.html")){
        return "/";
      }
      url.searchParams.set("v", version);
      if(url.origin === window.location.origin){
        return url.pathname + url.search + url.hash;
      }
      return url.href;
    }catch(_){
      return href;
    }
  }

  function getShortCodeFromLocation(){
    const params = new URLSearchParams(window.location.search);
    if(params.has("s")) return params.get("s");

    const match = window.location.pathname.match(/\/s\/([A-Za-z0-9]+)\/?$/);
    return match ? match[1] : null;
  }

  function virtualPage(pageId){
    return VIRTUAL_PAGES[pageId] || null;
  }

  window.LlogaritesRoutes = Object.freeze({
    fileBaseFor,
    getShortCodeFromLocation,
    isLocalRuntime,
    linkPagePath,
    shellPagePath,
    virtualPage,
    withVersion
  });
})();
