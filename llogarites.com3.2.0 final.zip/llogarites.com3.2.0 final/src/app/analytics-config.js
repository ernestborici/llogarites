// Vendos ketu Measurement ID nga Google Analytics 4, p.sh. G-XXXXXXXXXX
window.LLOGARITES_ANALYTICS_ID = "G-N401V1RJ9F";
