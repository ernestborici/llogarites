(function(){
  var routes=window.LlogaritesRoutes||null;

  function pagePath(baseName){
    if(routes && typeof routes.linkPagePath==="function"){
      return routes.linkPagePath(baseName);
    }

    if(baseName==="Kredia"){
      var isCreditLocalFile=window.location.protocol==="file:";
      return isCreditLocalFile ? "./index.html" : "/";
    }

    var fileNames={
      Kredia:"kredia",
      Paga:"paga",
      About:"about",
      FAQ:"faq",
      Privacy:"privacy"
    };
    var fileBase=fileNames[baseName]||baseName;
    var isLocalFile=window.location.protocol==="file:";
    var host=window.location.hostname;
    var isLocalHost=host==="localhost"||host==="127.0.0.1";
    return (!isLocalFile&&!isLocalHost) ? "/" + fileBase : "./" + fileBase + ".html";
  }

  function withVersion(href, version){
    if(routes && typeof routes.withVersion==="function"){
      return routes.withVersion(href, version);
    }

    if(!version || version==="auto") return href;
    try{
      var url=new URL(href, window.location.href);
      var host=window.location.hostname;
      var isLocalRuntime=window.location.protocol==="file:" || host==="localhost" || host==="127.0.0.1";
      if(!isLocalRuntime){
        if(url.origin===window.location.origin){
          return url.pathname + url.search + url.hash;
        }
        return url.href;
      }
      if(url.origin===window.location.origin && (url.pathname==="/" || url.pathname==="/index.html")){
        return "/";
      }
      url.searchParams.set("v", version);
      if(url.origin===window.location.origin){
        return url.pathname + url.search + url.hash;
      }
      return url.href;
    }catch(_){
      return href;
    }
  }

  function isStandaloneDirectPage(){
    return window.top===window;
  }

  function brandAssetPath(fileName){
    var isLocalFile=window.location.protocol==="file:";
    var host=window.location.hostname;
    var isLocalHost=host==="localhost"||host==="127.0.0.1";
    var prefix=(!isLocalFile&&!isLocalHost) ? "/" : "./";
    return prefix + "assets/brand/" + fileName;
  }

  function removeExistingShell(){
    document.querySelectorAll(".mobile-top-shell").forEach(function(node){
      node.remove();
    });
    if(document.body){
      document.body.classList.remove("mobile-top-shell-active","mobile-top-shell-menu-open");
    }
  }

  function buildShell(currentPage, version){
    removeExistingShell();
    var wrapper=document.createElement("div");
    wrapper.className="mobile-top-shell";
    wrapper.setAttribute("data-shell","ios-static");
    wrapper.innerHTML=
      '<header class="mobile-top-shell__header llogarites-top-header" data-shell="ios-static" aria-label="Main navigation">'+
        '<button type="button" class="mobile-top-shell__icon-btn llogarites-top-header__icon-btn llogarites-top-header__menu-btn" id="mobileTopShellMenuBtn" aria-label="Open menu" aria-controls="mobileTopShellSidebar" aria-expanded="false"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M5.5 7h13"/><path d="M5.5 12h13"/><path d="M5.5 17h13"/></svg></button>'+
        '<a class="mobile-top-shell__brand llogarites-top-header__brand" id="mobileTopShellBrand" href="./index.html" aria-label="LLOGARITES">'+
          '<img class="mobile-top-shell__brand-logo llogarites-top-header__brand-logo" src="'+brandAssetPath("logo-header.png")+'" alt="LLOGARITES" decoding="async">'+
        '</a>'+
        '<button type="button" class="mobile-top-shell__icon-btn llogarites-top-header__icon-btn llogarites-top-header__refresh-btn" id="mobileTopShellRefreshBtn" aria-label="Refresh page"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M19.1 6.35v4.85h-4.85"/><path d="M18.55 11.2a7.05 7.05 0 1 0-2.05 5"/></svg></button>'+
      '</header>'+
      '<div class="mobile-top-shell__overlay" id="mobileTopShellOverlay" hidden></div>'+
      '<aside class="mobile-top-shell__sidebar" id="mobileTopShellSidebar" hidden aria-hidden="true">'+
        '<nav class="mobile-top-shell__nav" aria-label="Menu">'+
          '<div class="mobile-top-shell__group">'+
            '<a class="mobile-top-shell__link" data-dest="Kredia" href="./index.html"><i data-lucide="calculator"></i><span>Kredia</span></a>'+
            '<a class="mobile-top-shell__link" data-dest="Paga" href="./paga.html"><i data-lucide="banknote"></i><span>Paga</span></a>'+
          '</div>'+
          '<div class="mobile-top-shell__group">'+
            '<a class="mobile-top-shell__link" data-dest="AboutInstall" href="./AboutInstall.html"><i data-lucide="download"></i><span>Install</span></a>'+
          '</div>'+
          '<div class="mobile-top-shell__footer">'+
            '<div>2026 &copy; Ernest Borici &bull; v'+version+'</div>'+
            '<div>All rights reserved &bull; llogarites.com <span class="mobile-top-shell__footer-links">'+
              '&bull; <a class="mobile-top-shell__footer-link" data-dest="FAQ" href="./faq.html">FAQ</a> '+
              '&bull; <a class="mobile-top-shell__footer-link" data-dest="Privacy" href="./privacy.html">Privacy</a> '+
              '&bull; <a class="mobile-top-shell__footer-link" data-dest="Terms" href="./Terms.html">Terms</a> '+
              '&bull; <a class="mobile-top-shell__footer-link" data-dest="About" href="./about.html">About</a>'+
            '</span></div>'+
          '</div>'+
        '</nav>'+
      '</aside>';

    document.body.insertBefore(wrapper,document.body.firstChild);
    document.body.classList.add("mobile-top-shell-active");

    var brand=document.getElementById("mobileTopShellBrand");
    var menuBtn=document.getElementById("mobileTopShellMenuBtn");
    var refreshBtn=document.getElementById("mobileTopShellRefreshBtn");
    var overlay=document.getElementById("mobileTopShellOverlay");
    var sidebar=document.getElementById("mobileTopShellSidebar");
    var links=document.querySelectorAll(".mobile-top-shell__link");
    var footerLinks=document.querySelectorAll(".mobile-top-shell__footer-link");
    if(brand) brand.setAttribute("href",withVersion(pagePath("Kredia"),version));
    links.forEach(function(link){
      var dest=link.getAttribute("data-dest");
      if(dest){
        link.setAttribute("href",withVersion(pagePath(dest),version));
        if(dest===currentPage){
          link.setAttribute("aria-current","page");
        }else{
          link.removeAttribute("aria-current");
        }
      }
    });
    footerLinks.forEach(function(link){
      var dest=link.getAttribute("data-dest");
      if(dest){
        link.setAttribute("href",withVersion(pagePath(dest),version));
        if(dest===currentPage){
          link.setAttribute("aria-current","page");
        }else{
          link.removeAttribute("aria-current");
        }
      }
    });

    function setMenuOpen(open){
      document.body.classList.toggle("mobile-top-shell-menu-open",open);
      overlay.hidden=!open;
      sidebar.hidden=!open;
      sidebar.setAttribute("aria-hidden",String(!open));
      menuBtn.setAttribute("aria-expanded",String(open));
    }

    var desktopSidebarMedia=window.matchMedia("(min-width: 1200px)");
    function syncSidebarForViewport(){
      if(desktopSidebarMedia.matches){
        document.body.classList.remove("mobile-top-shell-menu-open");
        overlay.hidden=true;
        sidebar.hidden=false;
        sidebar.setAttribute("aria-hidden","false");
        menuBtn.setAttribute("aria-expanded","false");
        return;
      }
      if(!document.body.classList.contains("mobile-top-shell-menu-open")){
        setMenuOpen(false);
      }
    }

    menuBtn.addEventListener("click",function(){
      if(desktopSidebarMedia.matches) return;
      setMenuOpen(sidebar.hidden);
    });
    refreshBtn.addEventListener("click",function(){
      window.location.reload();
    });
    overlay.addEventListener("click",function(){
      setMenuOpen(false);
    });
    function navigateInsideApp(event){
      if(event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      var link=event.currentTarget;
      if(!link || link.target) return;
      var href=link.getAttribute("href");
      if(!href || href.charAt(0)==="#") return;
      event.preventDefault();
      setMenuOpen(false);
      window.location.assign(href);
    }
    brand.addEventListener("click",navigateInsideApp);
    links.forEach(function(link){
      link.addEventListener("click",function(){
        setMenuOpen(false);
      });
      link.addEventListener("click",navigateInsideApp);
    });
    footerLinks.forEach(function(link){
      link.addEventListener("click",navigateInsideApp);
    });
    document.addEventListener("keydown",function(event){
      if(event.key==="Escape") setMenuOpen(false);
    });
    if(desktopSidebarMedia.addEventListener){
      desktopSidebarMedia.addEventListener("change",syncSidebarForViewport);
    }else if(desktopSidebarMedia.addListener){
      desktopSidebarMedia.addListener(syncSidebarForViewport);
    }
    window.addEventListener("resize",syncSidebarForViewport,{passive:true});
    syncSidebarForViewport();

    if(window.lucide && typeof window.lucide.createIcons==="function"){
      window.lucide.createIcons();
    }else{
      window.addEventListener("load",function(){
        if(window.lucide && typeof window.lucide.createIcons==="function"){
          window.lucide.createIcons();
        }
      },{once:true});
    }
  }

  function init(){
    if(!isStandaloneDirectPage()) return;
    var page=document.body.getAttribute("data-mobile-shell-page");
    var version=document.body.getAttribute("data-ui-version") || window.__LLOGARITES_APP_VERSION__ || "auto";
    if(!page) return;
    buildShell(page,version);
  }

  if(document.readyState==="loading"){
    document.addEventListener("DOMContentLoaded",init,{once:true});
  }else{
    init();
  }
})();
