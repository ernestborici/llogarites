document.addEventListener("DOMContentLoaded",()=>{
  if(window.lucide){ lucide.createIcons(); }

  const ACCESS_CODE = "eborici";
  const STORAGE_KEY = "llogarites-access-faq";
  const body = document.body;
  const form = document.getElementById("accessForm");
  const input = document.getElementById("accessCode");
  const error = document.getElementById("accessError");

  function normalise(value){
    return String(value || "").trim().toLowerCase();
  }

  function tracker(){
    try{
      if(window.top && window.top.LlogaritesAnalytics) return window.top.LlogaritesAnalytics;
    }catch(_){}
    return window.LlogaritesAnalytics || null;
  }

  function trackEvent(name, params){
    const analytics = tracker();
    if(analytics && typeof analytics.trackEvent === "function"){
      analytics.trackEvent(name, params || {});
    }
  }

  function hasAccess(){
    try{
      return localStorage.getItem(STORAGE_KEY) === "granted";
    }catch(_){
      return false;
    }
  }

  function grantAccess(remember){
    body.classList.remove("locked");
    if(remember){
      try{
        localStorage.setItem(STORAGE_KEY, "granted");
      }catch(_){}
    }
  }

  if(hasAccess()){
    grantAccess(false);
  }else if(input){
    input.focus();
  }

  if(form){
    form.addEventListener("submit",(event)=>{
      event.preventDefault();
      if(normalise(input.value) === ACCESS_CODE){
        error.hidden = true;
        grantAccess(true);
        trackEvent("protected_page_unlock",{ page_name:"faq" });
        return;
      }
      error.hidden = false;
      input.focus();
      input.select();
      trackEvent("protected_page_unlock_failed",{ page_name:"faq" });
    });
  }
});
