(function(){
  const parts=window.location.pathname.split("/").filter(Boolean);
  let base="";
  let code="";
  if(parts[0]==="s"){
    code=parts[1]||"";
  }else if(parts[1]==="s"){
    base="/"+parts[0];
    code=parts[2]||"";
  }
  if(code){
    window.location.replace(base+"/?s="+encodeURIComponent(code));
  }
})();
