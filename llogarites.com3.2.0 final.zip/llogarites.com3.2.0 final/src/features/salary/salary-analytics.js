/* Salary analytics helpers. */

  function salaryAmountBand(value){
    if(!Number.isFinite(value) || value < 0) return "unknown";
    if(value <= 50000) return "0-50k";
    if(value <= 100000) return "50k-100k";
    if(value <= 200000) return "100k-200k";
    if(value <= 300000) return "200k-300k";
    return "300k+";
  }

  function salaryAnalyticsTracker(){
    try{
      if(window.parent && window.parent !== window && window.parent.LlogaritesAnalytics){
        return window.parent.LlogaritesAnalytics;
      }
    }catch(_){
      return window.LlogaritesAnalytics || null;
    }

    return window.LlogaritesAnalytics || null;
  }

  function trackSalaryEvent(name, params){
    const analytics = salaryAnalyticsTracker();
    if(!analytics || typeof analytics.trackEvent !== "function" || !name) return;
    analytics.trackEvent(name, params || {});
  }
