/* Salary formatters and DOM render helpers. Load before salary-engine.js. */

  const INTEGER_FORMATTER = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0
  });
  const PERCENT_FORMATTER = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1
  });

  const SALARY_RULES_2026 = Object.freeze({
    minimumSalary: 50000,
    socialInsuranceCeiling: 186416,
    employee: Object.freeze({
      socialRate: 0.095,
      healthRate: 0.017
    }),
    employer: Object.freeze({
      socialRate: 0.15,
      healthRate: 0.017
    })
  });

  const elementCache = new Map();
  const salaryAnalyticsState = {
    lastGrossToNetKey: "",
    lastNetToGrossKey: ""
  };

  function formatInteger(value){
    return INTEGER_FORMATTER.format(Math.round(Math.max(0, Number(value) || 0)));
  }

  function parseAmountValue(rawValue){
    const raw = String(rawValue ?? "");
    const normalized = raw.replace(/[^0-9.,]/g, "").replace(/,/g, "");
    return parseFloat(normalized) || 0;
  }

  function parseAmountFromInput(id){
    const element = document.getElementById(id);
    return parseAmountValue(element && element.value);
  }

  function formatInputElement(element){
    if(!element) return;
    const digits = String(element.value ?? "").replace(/[^0-9]/g, "");
    element.value = digits ? Number(digits).toLocaleString("en-US") : "";
  }

  function getElement(id){
    if(!id) return null;
    if(elementCache.has(id)) return elementCache.get(id);
    const element = document.getElementById(id);
    elementCache.set(id, element || null);
    return element || null;
  }

  function renderValue(id, value){
    const element = getElement(id);
    if(!element) return;
    const unit = element.dataset.unit ? ` ${element.dataset.unit}` : "";
    element.textContent = `${formatInteger(value)}${unit}`;
    element.dataset.prev = String(value);
  }

  function renderTableAmount(id, value){
    const element = getElement(id);
    if(!element) return;
    element.textContent = formatInteger(value);
    element.dataset.prev = String(value);
  }

  function renderTablePercent(id, value){
    const element = getElement(id);
    if(!element) return;
    const safeValue = Math.max(0, Number(value) || 0);
    element.textContent = `${PERCENT_FORMATTER.format(safeValue)}%`;
    element.dataset.prev = String(safeValue);
  }

  function renderWarning(id, message){
    const element = getElement(id);
    if(!element) return;
    element.textContent = message || "";
  }
