/* Salary calculation engine. Formulas preserved from salary-page.js. */

  function normalizeGrossAmount(value){
    return Math.max(0, Number(value) || 0);
  }

  function employeeContributionBase(grossAmount){
    const gross = normalizeGrossAmount(grossAmount);
    if(gross === 0) return 0;
    return Math.max(SALARY_RULES_2026.minimumSalary, gross);
  }

  function calculateTap(grossAmount){
    const gross = normalizeGrossAmount(grossAmount);

    if(gross <= 50000) return 0;
    if(gross <= 60000) return (gross - 35000) * 0.13;
    if(gross <= 200000) return (gross - 30000) * 0.13;
    return 22100 + (gross - 200000) * 0.23;
  }

  function calculateEmployeeSocial(grossAmount){
    const cappedGross = Math.min(
      employeeContributionBase(grossAmount),
      SALARY_RULES_2026.socialInsuranceCeiling
    );
    return cappedGross * SALARY_RULES_2026.employee.socialRate;
  }

  function calculateEmployeeHealth(grossAmount){
    const gross = employeeContributionBase(grossAmount);
    return gross * SALARY_RULES_2026.employee.healthRate;
  }

  function calculateEmployerSocial(grossAmount){
    const cappedGross = Math.min(
      employeeContributionBase(grossAmount),
      SALARY_RULES_2026.socialInsuranceCeiling
    );
    return cappedGross * SALARY_RULES_2026.employer.socialRate;
  }

  function calculateEmployerHealth(grossAmount){
    const gross = employeeContributionBase(grossAmount);
    return gross * SALARY_RULES_2026.employer.healthRate;
  }

  function buildEmployeeBreakdown(grossAmount){
    const gross = normalizeGrossAmount(grossAmount);
    const social = calculateEmployeeSocial(gross);
    const health = calculateEmployeeHealth(gross);
    const tap = calculateTap(gross);
    const deductions = social + health + tap;

    return {
      gross,
      social,
      health,
      tap,
      deductions,
      net: gross - deductions
    };
  }

  function buildEmployerBreakdown(grossAmount){
    const gross = normalizeGrossAmount(grossAmount);
    const social = calculateEmployerSocial(gross);
    const health = calculateEmployerHealth(gross);
    const contributions = social + health;

    return {
      social,
      health,
      contributions
    };
  }

  function percentOfGross(amount, grossAmount){
    const gross = normalizeGrossAmount(grossAmount);
    if(gross <= 0) return 0;
    return (Math.max(0, Number(amount) || 0) / gross) * 100;
  }

  function diffBreakdown(totalBreakdown, baseBreakdown){
    return {
      gross: totalBreakdown.gross - baseBreakdown.gross,
      social: totalBreakdown.social - baseBreakdown.social,
      health: totalBreakdown.health - baseBreakdown.health,
      tap: totalBreakdown.tap - baseBreakdown.tap,
      deductions: totalBreakdown.deductions - baseBreakdown.deductions,
      net: totalBreakdown.net - baseBreakdown.net
    };
  }

  function diffEmployer(totalEmployer, baseEmployer){
    return {
      social: totalEmployer.social - baseEmployer.social,
      health: totalEmployer.health - baseEmployer.health,
      contributions: totalEmployer.contributions - baseEmployer.contributions
    };
  }

  function calculateGrossToNet(args){
    const salaryGross = args && args.salaryGross || 0;
    const bonusGross = args && args.bonusGross || 0;

    const salary = buildEmployeeBreakdown(salaryGross);
    const salaryEmployer = buildEmployerBreakdown(salaryGross);

    const totalGross = salary.gross + normalizeGrossAmount(bonusGross);
    const total = buildEmployeeBreakdown(totalGross);
    const totalEmployer = buildEmployerBreakdown(totalGross);

    const bonus = diffBreakdown(total, salary);
    const bonusEmployer = diffEmployer(totalEmployer, salaryEmployer);

    return {
      rules: SALARY_RULES_2026,
      salary,
      bonus,
      total,
      employer: {
        salary: salaryEmployer,
        bonus: bonusEmployer,
        total: totalEmployer
      }
    };
  }

  function grossNetDifference(baseGross, bonusGross){
    return calculateGrossToNet({
      salaryGross: baseGross,
      bonusGross
    }).bonus.net;
  }

  function solveStandaloneGrossFromNet(targetNet){
    const target = Math.max(0, Number(targetNet) || 0);
    let low = 0;
    let high = Math.max(1000000, target * 2 + 100000);

    while(buildEmployeeBreakdown(high).net < target){
      high *= 2;
    }

    for(let index = 0; index < 80; index += 1){
      const middle = (low + high) / 2;
      if(buildEmployeeBreakdown(middle).net < target){
        low = middle;
      }else{
        high = middle;
      }
    }

    return Math.round(high);
  }

  function solveBonusGrossFromNet(baseGross, targetBonusNet){
    const target = Math.max(0, Number(targetBonusNet) || 0);
    let low = 0;
    let high = Math.max(1000000, target * 2 + 100000);

    while(grossNetDifference(baseGross, high) < target){
      high *= 2;
    }

    for(let index = 0; index < 80; index += 1){
      const middle = (low + high) / 2;
      if(grossNetDifference(baseGross, middle) < target){
        low = middle;
      }else{
        high = middle;
      }
    }

    return Math.round(high);
  }

  function calculateNetToGross(args){
    const salaryNet = args && args.salaryNet || 0;
    const bonusNet = args && args.bonusNet || 0;

    const salaryGross = solveStandaloneGrossFromNet(salaryNet);
    const bonusGross = solveBonusGrossFromNet(salaryGross, bonusNet);

    return calculateGrossToNet({
      salaryGross,
      bonusGross
    });
  }
