/* Salary page bootstrap. Requires salary-formatters, salary-engine, salary-analytics and salary-ui. */

  function initSalaryPage(){
    const pagaInput = document.getElementById("paga");
    const bonusInput = document.getElementById("bonus");
    const pagaNetoInput = document.getElementById("pagaNetoInput");
    const bonusNetoInput = document.getElementById("bonusNetoInput");

    if(!pagaInput || !bonusInput || !pagaNetoInput || !bonusNetoInput) return;

    let grossToNetTimer;

    function calculateAndRenderGrossToNet(shouldTrack){
      let salaryGross = parseAmountFromInput("paga");
      let bonusGross = parseAmountFromInput("bonus");

      if(salaryGross < 0){
        salaryGross = 0;
        pagaInput.value = "0";
      }
      if(bonusGross < 0){
        bonusGross = 0;
        bonusInput.value = "0";
      }

      const warnings = buildGrossWarnings(salaryGross, bonusGross);
      renderWarning("pagaWarning", warnings.salary);
      renderWarning("bonusWarning", warnings.bonus);

      renderGrossToNet(calculateGrossToNet({ salaryGross, bonusGross }));

      if(shouldTrack){
        const eventKey = [salaryGross, bonusGross].join("|");
        if(salaryAnalyticsState.lastGrossToNetKey !== eventKey){
          trackSalaryEvent("salary_calculation_completed", {
            direction: "gross_to_net",
            salary_band: salaryAmountBand(salaryGross),
            bonus_band: salaryAmountBand(bonusGross)
          });
          salaryAnalyticsState.lastGrossToNetKey = eventKey;
        }
      }
    }

    function calculateAndRenderNetToGross(shouldTrack){
      let salaryNet = parseAmountFromInput("pagaNetoInput");
      let bonusNet = parseAmountFromInput("bonusNetoInput");

      if(salaryNet < 0){
        salaryNet = 0;
        pagaNetoInput.value = "0";
      }
      if(bonusNet < 0){
        bonusNet = 0;
        bonusNetoInput.value = "0";
      }

      renderNetToGross(calculateNetToGross({ salaryNet, bonusNet }));

      if(shouldTrack){
        const eventKey = [salaryNet, bonusNet].join("|");
        if(salaryAnalyticsState.lastNetToGrossKey !== eventKey){
          trackSalaryEvent("salary_calculation_completed", {
            direction: "net_to_gross",
            salary_band: salaryAmountBand(salaryNet),
            bonus_band: salaryAmountBand(bonusNet)
          });
          salaryAnalyticsState.lastNetToGrossKey = eventKey;
        }
      }
    }

    function calculateGrossToNetDebounced(shouldTrack){
      window.clearTimeout(grossToNetTimer);
      grossToNetTimer = window.setTimeout(() => {
        calculateAndRenderGrossToNet(shouldTrack);
      }, 150);
    }

    bindFormattedAmountInput(
      pagaInput,
      () => calculateGrossToNetDebounced(true),
      () => calculateAndRenderGrossToNet(true)
    );

    bindFormattedAmountInput(
      bonusInput,
      () => calculateGrossToNetDebounced(true),
      () => calculateAndRenderGrossToNet(true)
    );

    [pagaInput, bonusInput, pagaNetoInput, bonusNetoInput].forEach((element) => {
      formatInputElement(element);
    });

    [pagaNetoInput, bonusNetoInput].forEach((element) => {
      bindFormattedAmountInput(
        element,
        () => calculateAndRenderNetToGross(true),
        () => calculateAndRenderNetToGross(true)
      );
    });

    bindFocusSelect(["paga", "bonus", "pagaNetoInput", "bonusNetoInput"]);

    [
      "pagaNeto",
      "bonusNeto",
      "totalNeto",
      "pagaBrutoFromNeto",
      "bonusBrutoFromNeto",
      "totalBrutoFromNeto",
      "totalBruto",
      "totalNetoFromNeto"
    ].forEach(setupSelectableResult);

    setupTabs();
    calculateAndRenderGrossToNet(false);
    calculateAndRenderNetToGross(false);

    if(window.lucide && typeof window.lucide.createIcons === "function"){
      window.lucide.createIcons();
    }
  }

  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", initSalaryPage, { once:true });
  }else{
    initSalaryPage();
  }
