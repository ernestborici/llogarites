/* Salary UI binding helpers. */

  function renderEmployeeTable(prefix, result){
    renderTableAmount(`${prefix}GrossSalary`, result.salary.gross);
    renderTableAmount(`${prefix}GrossBonus`, result.bonus.gross);

    renderTableAmount(`${prefix}SocialSalary`, result.salary.social);
    renderTableAmount(`${prefix}SocialBonus`, result.bonus.social);

    renderTableAmount(`${prefix}HealthSalary`, result.salary.health);
    renderTableAmount(`${prefix}HealthBonus`, result.bonus.health);

    renderTableAmount(`${prefix}TapSalary`, result.salary.tap);
    renderTableAmount(`${prefix}TapBonus`, result.bonus.tap);

    renderTableAmount(`${prefix}DeductionsSalary`, result.salary.deductions);
    renderTableAmount(`${prefix}DeductionsBonus`, result.bonus.deductions);

    renderTableAmount(`${prefix}NetSalary`, result.salary.net);
    renderTableAmount(`${prefix}NetBonus`, result.bonus.net);
  }

  function renderEmployerTable(prefix, result){
    renderTableAmount(`${prefix}GrossSalary`, result.salary.gross);
    renderTableAmount(`${prefix}GrossBonus`, result.bonus.gross);

    renderTableAmount(`${prefix}SocialSalary`, result.employer.salary.social);
    renderTableAmount(`${prefix}SocialBonus`, result.employer.bonus.social);

    renderTableAmount(`${prefix}HealthSalary`, result.employer.salary.health);
    renderTableAmount(`${prefix}HealthBonus`, result.employer.bonus.health);

    renderTableAmount(`${prefix}ContribSalary`, result.employer.salary.contributions);
    renderTableAmount(`${prefix}ContribBonus`, result.employer.bonus.contributions);

    renderTablePercent(`${prefix}EmployeeTaxPercentSalary`, percentOfGross(result.salary.deductions, result.salary.gross));
    renderTablePercent(`${prefix}EmployeeTaxPercentBonus`, percentOfGross(result.bonus.deductions, result.bonus.gross));

    renderTablePercent(`${prefix}EmployerTaxPercentSalary`, percentOfGross(result.employer.salary.contributions, result.salary.gross));
    renderTablePercent(`${prefix}EmployerTaxPercentBonus`, percentOfGross(result.employer.bonus.contributions, result.bonus.gross));

    renderTablePercent(
      `${prefix}TotalTaxPercentSalary`,
      percentOfGross(result.salary.deductions + result.employer.salary.contributions, result.salary.gross)
    );
    renderTablePercent(
      `${prefix}TotalTaxPercentBonus`,
      percentOfGross(result.bonus.deductions + result.employer.bonus.contributions, result.bonus.gross)
    );
  }

  function renderGrossToNet(result){
    renderValue("pagaNeto", result.salary.net);
    renderValue("bonusNeto", result.bonus.net);
    renderValue("totalBruto", result.total.gross);
    renderValue("totalNeto", result.total.net);
    renderEmployeeTable("employee", result);
    renderEmployerTable("employer", result);
  }

  function renderNetToGross(result){
    renderValue("pagaBrutoFromNeto", result.salary.gross);
    renderValue("bonusBrutoFromNeto", result.bonus.gross);
    renderValue("totalNetoFromNeto", result.total.net);
    renderValue("totalBrutoFromNeto", result.total.gross);
    renderEmployeeTable("employeeFromNeto", result);
    renderEmployerTable("employerFromNeto", result);
  }

  function setupSelectableResult(id){
    const element = document.getElementById(id);
    if(!element) return;
    element.addEventListener("click", () => {
      const range = document.createRange();
      range.selectNodeContents(element);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
    });
  }

  function buildGrossWarnings(salaryGross, bonusGross){
    const warnings = {
      salary: "",
      bonus: ""
    };

    if(salaryGross > 0 && salaryGross < SALARY_RULES_2026.minimumSalary){
      warnings.salary = `Kujdes: Nga 1 Janari 2026, paga minimale eshte ${formatInteger(SALARY_RULES_2026.minimumSalary)} LEK.`;
    }

    if(bonusGross <= 0) return warnings;

    const ceiling = SALARY_RULES_2026.socialInsuranceCeiling;
    const totalGross = salaryGross + bonusGross;

    if(salaryGross >= ceiling){
      warnings.bonus = `Bonusi nuk mban me sigurime shoqerore, sepse paga ka arritur tavanin ${formatInteger(ceiling)} LEK.`;
      return warnings;
    }

    if(totalGross > ceiling){
      warnings.bonus = `Vetem ${formatInteger(ceiling - salaryGross)} LEK nga bonusi mban sigurime shoqerore; pjesa tjeter del mbi tavanin ${formatInteger(ceiling)} LEK.`;
    }

    return warnings;
  }

  function setupTabs(){
    document.querySelectorAll(".seg-btn").forEach((button) => {
      button.addEventListener("click", () => {
        document.querySelectorAll(".seg-btn").forEach((candidate) => {
          candidate.classList.remove("active");
        });
        button.classList.add("active");

        const target = button.getAttribute("data-target");
        document.querySelectorAll(".calc-panel").forEach((panel) => {
          panel.classList.remove("active");
        });
        const targetPanel = document.getElementById(target);
        if(targetPanel) targetPanel.classList.add("active");
      });
    });
  }

  function bindFocusSelect(ids){
    ids.forEach((id) => {
      const element = document.getElementById(id);
      if(!element) return;
      element.addEventListener("focus", () => element.select());
      element.addEventListener("click", () => element.select());
    });
  }

  function bindFormattedAmountInput(element, onRealtime, onCommit){
    if(!element) return;

    element.addEventListener("input", () => {
      formatInputElement(element);
      if(typeof onRealtime === "function") onRealtime();
    });

    element.addEventListener("change", () => {
      formatInputElement(element);
      if(typeof onCommit === "function") onCommit();
    });

    element.addEventListener("blur", () => {
      formatInputElement(element);
      if(typeof onCommit === "function") onCommit();
    });
  }
