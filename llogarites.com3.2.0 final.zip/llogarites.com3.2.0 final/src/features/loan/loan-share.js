const BASE62="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
const SHARE_URL_FALLBACK_ORIGIN="https://llogarites.com";
const SHARE_FORMAT=2n;

function base62Encode(num){
  if(num===0n) return "0";
  let output="";
  let value=num;
  while(value>0n){
    const remainder=value%62n;
    output=BASE62[Number(remainder)]+output;
    value=value/62n;
  }
  return output;
}

function base62Decode(code){
  let value=0n;
  for(const character of String(code||"")){
    const index=BASE62.indexOf(character);
    if(index<0) return null;
    value=value*62n+BigInt(index);
  }
  return value;
}

function loanProductIndex(product){
  const index=PRODUCT_LIST.indexOf(product);
  return index>=0 ? index : 0;
}

function encodeSharedLoan(params){
  const principal=Math.max(0,Math.min(1073741823,Math.round(Number(params.p)||0)));
  const months=Math.max(0,Math.min(1023,parseInt(params.m,10)||0));
  const rateBp=Math.max(0,Math.min(32767,Math.round((Number(params.r)||0)*100)));
  const currencyBit=String(params.curr||"LEK").toUpperCase()==="EUR" ? 1n : 0n;
  const productIndex=loanProductIndex(params.prod);

  let value=SHARE_FORMAT;
  value=(value<<1n)|currencyBit;
  value=(value<<4n)|BigInt(productIndex);
  value=(value<<10n)|BigInt(months);
  value=(value<<15n)|BigInt(rateBp);
  value=(value<<30n)|BigInt(principal);
  return base62Encode(value);
}

function decodeSharedLoan(code){
  if(!code) return null;
  let value=base62Decode(code);
  if(value===null) return null;

  const principal=Number(value&((1n<<30n)-1n)); value>>=30n;
  const rateBp=Number(value&((1n<<15n)-1n)); value>>=15n;
  const months=Number(value&((1n<<10n)-1n)); value>>=10n;
  const productIndex=Number(value&15n); value>>=4n;
  const currency=Number(value&1n)===1 ? "EUR" : "LEK"; value>>=1n;
  const format=Number(value);

  if(format!==Number(SHARE_FORMAT)) return null;

  return {
    P:principal,
    n:months,
    rate:rateBp/100,
    prod:PRODUCT_LIST[productIndex]||PRODUCT_LIST[0],
    curr:currency
  };
}

function base64UrlEncodeText(text){
  const bytes=new TextEncoder().encode(text);
  let binary="";
  bytes.forEach(byte=>{
    binary+=String.fromCharCode(byte);
  });
  return btoa(binary).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}

function base64UrlDecodeText(value){
  const source=String(value||"");
  const base64=source.replace(/-/g,"+").replace(/_/g,"/");
  const padded=base64+"=".repeat((4-base64.length%4)%4);
  const binary=atob(padded);
  const bytes=Uint8Array.from(binary,character=>character.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function compactDateValue(value){
  const match=String(value||"").match(/^20(\d{2})-(\d{2})-(\d{2})$/);
  return match ? `${match[1]}${match[2]}${match[3]}` : "";
}

function expandCompactDateValue(value){
  const compact=String(value||"");
  if(/^\d{6}$/.test(compact)){
    return `20${compact.slice(0,2)}-${compact.slice(2,4)}-${compact.slice(4,6)}`;
  }
  return isIsoDateValue(compact) ? compact : "";
}

function normalizeSharedLoanDetails(details){
  if(!details || typeof details!=="object") return null;
  if(details.v===2){
    const normalized={
      v:2,
      showDetails:details.x===1 || details.x===true,
      disb:expandCompactDateValue(details.d),
      firstPayment:expandCompactDateValue(details.f),
      customerName:details.n || "",
      feeRate:details.r || "",
      feeAmount:details.e || "",
      feeAmountCustom:details.o===1 || details.o===true,
      activeClosing:details.c || ""
    };
    return normalized;
  }
  return details;
}

function encodeSharedLoanDetails(details){
  if(!details) return "";
  try{
    return base64UrlEncodeText(JSON.stringify(details || {}));
  }catch(_){
    return "";
  }
}

function decodeSharedLoanDetails(payload){
  if(!payload) return null;
  try{
    const decoded=JSON.parse(base64UrlDecodeText(payload));
    return normalizeSharedLoanDetails(decoded);
  }catch(_){
    return null;
  }
}

function getSharedLoanDetailsFromUrl(){
  const params=new URLSearchParams(window.location.search);
  return decodeSharedLoanDetails(params.get("d"));
}

function isIsoDateValue(value){
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value||""));
}

function readInputValue(id){
  return String(document.getElementById(id)?.value||"").trim();
}

function writeInputValue(id,value){
  const input=document.getElementById(id);
  if(!input || value===undefined || value===null) return;
  input.value=String(value);
}

function parseLoanFeeRateValue(value){
  const parsed=parseFloat(String(value||"").replace(/,/g,".").replace(/[^0-9.]/g,""));
  return Number.isFinite(parsed) ? parsed : NaN;
}

function isCustomLoanFeeRate(value){
  if(!String(value||"").trim()) return false;
  if(typeof getContractFeeRate!=="function") return true;
  const months=AppController.parseTermMonths();
  const defaultRate=getContractFeeRate(months);
  const parsed=parseLoanFeeRateValue(value);
  if(!Number.isFinite(defaultRate) || !Number.isFinite(parsed)) return true;
  return Math.abs(parsed-defaultRate)>0.0001;
}

function isSharedLoanCustomDate(disbursementValue,firstPaymentValue){
  if(!isIsoDateValue(disbursementValue)) return false;
  const today=typeof formatLocalDateForInput==="function" ? formatLocalDateForInput(new Date()) : "";
  if(disbursementValue!==today) return true;
  if(!isIsoDateValue(firstPaymentValue)) return false;
  if(typeof parseLocalDate!=="function" || typeof isCustomFirstPaymentDate!=="function") return true;
  return isCustomFirstPaymentDate(parseLocalDate(disbursementValue),firstPaymentValue);
}

function buildSharedLoanDetails(){
  const disbursement=readInputValue("disbursement");
  const firstPayment=readInputValue("firstPaymentDate");
  const customerName=readInputValue("loanCustomerName");
  const activeClosing=readInputValue("loanActiveClosing");
  const feeRate=readInputValue("loanOptionFeeRate");
  const feeAmount=readInputValue("loanOptionFee");
  const feeInput=document.getElementById("loanOptionFee");
  const hasCustomFeeAmount=typeof isLoanFeeAmountCustom==="function" && isLoanFeeAmountCustom(feeInput);
  const hasVisibleDetails=customerName!=="" || activeClosing!=="" || isCustomLoanFeeRate(feeRate) || hasCustomFeeAmount;
  const hasCustomDate=isSharedLoanCustomDate(disbursement,firstPayment);

  if(!hasVisibleDetails && !hasCustomDate){
    return null;
  }

  const details={v:2};

  if(hasCustomDate || hasVisibleDetails){
    const compactDisbursement=compactDateValue(disbursement);
    const compactFirstPayment=compactDateValue(firstPayment);
    if(compactDisbursement) details.d=compactDisbursement;
    if(compactFirstPayment) details.f=compactFirstPayment;
  }

  if(hasVisibleDetails){
    details.x=1;
    if(customerName) details.n=customerName;
    if(isCustomLoanFeeRate(feeRate)) details.r=feeRate;
    if(hasCustomFeeAmount){
      details.o=1;
      const feeDigits=feeAmount.replace(/[^0-9]/g,"");
      if(feeDigits) details.e=feeDigits;
    }
    if(activeClosing) details.c=activeClosing.replace(/[^0-9]/g,"");
  }

  return details;
}

function applySharedLoanDetails(details){
  window.__sharedLoanShowDetails=!!(details && details.showDetails);
  if(!details) return;

  const disbursement=document.getElementById("disbursement");
  const firstPayment=document.getElementById("firstPaymentDate");
  if(disbursement && isIsoDateValue(details.disb)){
    disbursement.value=details.disb;
  }
  if(firstPayment && isIsoDateValue(details.firstPayment)){
    firstPayment.value=details.firstPayment;
  }else if(disbursement && disbursement.value && typeof syncFirstPaymentDateFromDisbursement==="function"){
    syncFirstPaymentDateFromDisbursement();
  }

  if(!details.showDetails) return;

  writeInputValue("loanCustomerName",details.customerName);
  writeInputValue("loanOptionFeeRate",details.feeRate);
  if(details.feeAmountCustom){
    writeInputValue("loanOptionFee",details.feeAmount);
    if(typeof setLoanFeeAmountMode==="function"){
      setLoanFeeAmountMode(document.getElementById("loanOptionFee"),"custom");
    }
  }
  writeInputValue("loanActiveClosing",details.activeClosing);
  if(typeof normalizeLoanOptionFeeRateInput==="function"){
    normalizeLoanOptionFeeRateInput(document.getElementById("loanOptionFeeRate"));
  }
  if(details.feeAmountCustom && typeof formatLoanOptionAmountInput==="function"){
    formatLoanOptionAmountInput(document.getElementById("loanOptionFee"));
  }
  if(typeof formatLoanOptionAmountInput==="function"){
    formatLoanOptionAmountInput(document.getElementById("loanActiveClosing"));
  }
  if(typeof updateLoanOptionNetTotal==="function"){
    updateLoanOptionNetTotal();
  }
}

function getSharedLoanOrigin(){
  try{
    const origin=window.location?.origin || "";
    const protocol=window.location?.protocol || "";
    if(origin && (protocol==="https:" || protocol==="http:")){
      return origin.replace(/\/+$/,"");
    }
  }catch(_){}
  return SHARE_URL_FALLBACK_ORIGIN;
}

function buildSharedLoanUrl(code,details){
  const payload=encodeSharedLoanDetails(details);
  const suffix=payload ? `?d=${encodeURIComponent(payload)}` : "";
  return `${getSharedLoanOrigin()}/s/${encodeURIComponent(code)}${suffix}`;
}

function suppressWhatsAppLinkPreview(url){
  // Keeps the URL visible in the message while preventing WhatsApp from building a rich preview.
  return String(url||"").replace(/^(https?:\/\/)/i,"$1\u2060");
}

function getFirstInstallmentText(){
  const firstInstallment=document.querySelector("#schedule tr.schedule-row td:nth-child(3)");
  return String(firstInstallment?.textContent||"").trim();
}

function buildWhatsAppLoanMessage(details){
  const currencyLabel=displayCurrency(normalizeCurrency(details.currency));
  return `${details.product}
* Shuma: *${Number(details.principal).toLocaleString("en-US")} ${currencyLabel}*
* Afati: *${details.months} muaj*
* Kesti: *${details.installment} ${currencyLabel}/muaj*
Kalendari i pagesave:
\`\`\`${String(details.url||"").replace(/^https?:\/\//i,"")}\`\`\``;
}

function shareWhatsApp(){
  const principal=AppController.parsePrincipalValue();
  const months=AppController.parseTermMonths();
  const rate=AppController.parseRateValue();
  const productInput=document.getElementById("product");
  let product=productInput?.value || "";
  const currency=document.getElementById("currency").value || "LEK";

  if(!product || product==="Zgjidh Produktin"){
    product=PRODUCT_LIST[0] || "KREDI KONSUMATORE";
    if(productInput){
      productInput.value=product;
      if(typeof syncProductSelectVisualState==="function") syncProductSelectVisualState();
      if(typeof updateScheduleProduct==="function") updateScheduleProduct();
    }
  }

  if(!Number.isFinite(principal) || principal<=0 || !Number.isFinite(months) || months<=0 || !Number.isFinite(rate) || rate<=0){
    window.alert("Ploteso te dhenat e kredise para se ta shperndash ne WhatsApp.");
    return;
  }

  AppController.calculate({
    source:"share",
    revealResults:false
  });

  const installment=getFirstInstallmentText();
  if(!installment){
    window.alert("Tabela e amortizimit nuk u krijua. Kontrollo te dhenat e kredise.");
    return;
  }

  const code=encodeSharedLoan({p:principal,m:months,r:rate,prod:product,curr:currency});
  const url=buildSharedLoanUrl(code,buildSharedLoanDetails());
  const message=buildWhatsAppLoanMessage({
    product,
    principal,
    months,
    rate,
    currency,
    installment,
    url
  });

  try{
    trackLoanEvent("share_whatsapp",{
      content_type:"loan_schedule",
      product,
      currency
    });
  }catch(_){}

  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`,"_blank");
}

window.shareWhatsApp=shareWhatsApp;
window.encodeSharedLoan=encodeSharedLoan;
window.decodeSharedLoan=decodeSharedLoan;
window.decodeSharedLoanDetails=decodeSharedLoanDetails;
window.getSharedLoanDetailsFromUrl=getSharedLoanDetailsFromUrl;
window.applySharedLoanDetails=applySharedLoanDetails;
window.getSharedLoanOrigin=getSharedLoanOrigin;
window.buildSharedLoanUrl=buildSharedLoanUrl;
