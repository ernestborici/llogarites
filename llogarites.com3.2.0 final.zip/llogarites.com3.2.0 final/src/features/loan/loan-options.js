/* ======================================================
   WHATSAPP SHARE + SHORT LINK
====================================================== */

const PRODUCT_LIST=[
"KREDI KONSUMATORE",
"KREDI PERSONALE",
"KREDI BIZNESI",
"KREDI \"PER INVESTIME NE BANESE\"",
"KREDI \"MBESHTESIM BIZNESIN TUAJ\"",
"KREDI \"PER TURIZEM & AGRO\"",
"KREDI \"PER GRATE\"",
"KREDI \"VETEM PER TY\""
];

const PRODUCT_LIMITS={"KREDI KONSUMATORE":{"LEK":{"labels":["HIPOTEKE","RBS","Me Garantor","Pa Garantor"],"rows":[{"amount":[50000,200000],"months":[6,36],"rates":[null,null,33.0,35.5]},{"amount":[220000,600000],"months":[6,48],"rates":[null,null,25.5,26.0]}]}},"KREDI PERSONALE":{"LEK":{"labels":["HIPOTEKE","RBS","Me Garantor","Pa Garantor"],"rows":[{"amount":[50000,300000],"months":[6,36],"rates":[null,null,33.0,35.5]},{"amount":[320000,600000],"months":[6,48],"rates":[null,27.0,28.0,null]},{"amount":[620000,1500000],"months":[6,60],"rates":[24.5,25.5,26.5,null]},{"amount":[1500001,2000000],"months":[6,72],"rates":[24.0,24.5,null,null]}]}},"KREDI BIZNESI":{"LEK":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[100000,1300000],"months":[6,60],"rates":[22.5,23.5,24.5]},{"amount":[1300001,2700000],"months":[6,72],"rates":[21.5,22.5,null]},{"amount":[2700001,4500000],"months":[6,84],"rates":[21.0,null,null]},{"amount":[4500001,6000000],"months":[6,96],"rates":[19.0,null,null]},{"amount":[6000001,15000000],"months":[6,96],"rates":[18.0,null,null]},{"amount":[15000000,null],"months":[6,120],"rates":[17.0,null,null]}]},"EURO":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[1000,13000],"months":[6,60],"rates":[22.5,23.5,24.5]},{"amount":[13001,27000],"months":[6,72],"rates":[21.5,22.5,null]},{"amount":[27001,45000],"months":[6,84],"rates":[21.0,null,null]},{"amount":[45001,60000],"months":[6,96],"rates":[19.0,null,null]},{"amount":[60001,150000],"months":[6,96],"rates":[18.0,null,null]},{"amount":[150000,null],"months":[6,120],"rates":[17.0,null,null]}]}},"KREDI \"MBESHTESIM BIZNESIN TUAJ\"":{"LEK":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[300000,1000000],"months":[6,60],"rates":[null,21.0,21.5]},{"amount":[1000001,2000000],"months":[6,72],"rates":[19.0,21.0,null]},{"amount":[2000001,3000000],"months":[6,84],"rates":[18.5,19.0,null]}]},"EURO":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[2000,8000],"months":[6,60],"rates":[null,21.0,21.5]},{"amount":[8001,15000],"months":[6,72],"rates":[19.0,21.0,null]},{"amount":[15001,25000],"months":[6,84],"rates":[18.5,19.0,null]}]}},"KREDI \"PER TURIZEM & AGRO\"":{"LEK":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[100000,1300000],"months":[6,48],"rates":[18.0,19.0,20.0]},{"amount":[1300001,2700000],"months":[6,60],"rates":[17.0,18.0,null]},{"amount":[2700001,4500000],"months":[6,72],"rates":[16.0,null,null]},{"amount":[4500001,6000000],"months":[6,84],"rates":[15.0,null,null]}]},"EURO":{"labels":["HIPOTEKE","RBS","PA KOLATERAL"],"rows":[{"amount":[1000,13000],"months":[6,48],"rates":[18.0,19.0,20.0]},{"amount":[13001,27000],"months":[6,60],"rates":[17.0,18.0,null]},{"amount":[27001,45000],"months":[6,72],"rates":[16.0,null,null]},{"amount":[45001,60000],"months":[6,84],"rates":[15.0,null,null]}]}},"KREDI \"PER INVESTIME NE BANESE\"":{"LEK":{"labels":["HIPOTEKE","RBS","Me Garantor","Pa Garantor"],"rows":[{"amount":[50000,300000],"months":[6,36],"rates":[null,null,29.0,32.0]},{"amount":[320000,600000],"months":[6,48],"rates":[null,24.0,25.5,null]},{"amount":[620000,1500000],"months":[6,60],"rates":[23.0,23.5,null,null]}]}},"KREDI \"PER GRATE\"":{"LEK":{"labels":["HIPOTEKE","RBS","Me Garantor","Pa Garantor"],"rows":[{"amount":[50000,300000],"months":[6,36],"rates":[null,null,29.0,31.0]},{"amount":[320000,600000],"months":[6,48],"rates":[null,null,27.0,28.0]},{"amount":[50000,300000],"months":[6,36],"rates":[null,null,null,27.0]},{"amount":[320000,600000],"months":[6,48],"rates":[null,null,25.0,26.0]}]}},"KREDI \"VETEM PER TY\"":{"LEK":{"labels":["HIPOTEKE","RBS","Me Garantor","Pa Garantor"],"rows":[{"amount":[30000,200000],"months":[12,36],"rates":[null,null,null,35.5]}]}}};

const RATE_INPUT_MIN=0;
const RATE_INPUT_MAX=99;

function normalizeRateInputValue(raw){
const cleaned=String(raw||"").replace(/,/g,".").replace(/[^0-9.]/g,"");
const parts=cleaned.split(".");
const integerPart=parts.shift()||"";
const decimalPart=parts.join("").slice(0,2);
const normalized=integerPart+(parts.length?`.${decimalPart}`:"");
if(!normalized||normalized===".") return "";
const numericValue=parseFloat(normalized);
if(!Number.isFinite(numericValue)) return "";
const inputMax=getRateInputMax();
if(numericValue>inputMax) return formatUnitNumber(inputMax);
return normalized;
}

function applyRateInputLimit(){
const input=document.getElementById("rate");
if(!input) return;
input.min=String(RATE_INPUT_MIN);
input.max=String(getRateInputMax());
input.title=`Max ${formatUnitNumber(getRateInputMax())}%`;
input.value=normalizeRateInputValue(input.value);
updateRateUnitSuffixState();
}

function normalizeCurrency(curr){
  if(curr==="EUR") return "EURO";
  return curr;
}

function displayCurrency(curr){
  if(curr==="LEK") return "Leke";
  if(curr==="EURO") return "Euro";
  return curr;
}

function displayCurrencyCode(curr){
  return normalizeCurrency(curr)==="EURO" ? "EUR" : "ALL";
}

function getProductData(){
  const prod=document.getElementById("product").value;
  const curr=normalizeCurrency(document.getElementById("currency").value);
  return PRODUCT_LIMITS[prod]?.[curr]||null;
}

function getRangesForSelection(){
  return getProductData()?.rows||[];
}

function getRateLabels(){
  return getProductData()?.labels||[];
}

function getMatchedRange(){
  const amount=AppController.parsePrincipalValue();
  if(!Number.isFinite(amount)) return null;
  const ranges=getRangesForSelection();
  return ranges.find(r=>amount>=r.amount[0] && (r.amount[1]===null || amount<=r.amount[1]))||null;
}

function hasPrincipalEntry(){
  const input=document.getElementById("principal");
  return !!String(input?.value||"").replace(/[^0-9]/g,"");
}

function shouldShowInvalid(options){
  return !options || options.showInvalid!==false;
}

function applyRangeValidationClass(input, ok, options){
  if(ok){
    input.classList.add("is-valid");
    input.removeAttribute("aria-invalid");
    return;
  }
  if(shouldShowInvalid(options)){
    input.classList.add("is-invalid");
    input.setAttribute("aria-invalid","true");
  }else{
    input.removeAttribute("aria-invalid");
  }
}

function validatePrincipalRange(options){
  const input=document.getElementById("principal");
  input.classList.remove("is-valid","is-invalid");
  input.removeAttribute("aria-invalid");
  const val=AppController.parsePrincipalValue();
  if(Number.isFinite(val) && val>PRINCIPAL_INPUT_MAX){
    if(shouldShowInvalid(options)){
      input.classList.add("is-invalid");
      input.setAttribute("aria-invalid","true");
    }
    return;
  }
  const ranges=getRangesForSelection();
  if(!Number.isFinite(val) || !ranges.length){
    return;
  }
  const ok=ranges.some(r=>val>=r.amount[0] && (r.amount[1]===null || val<=r.amount[1]));
  applyRangeValidationClass(input,ok,options);
}

function validateMonthsRange(options){
  const input=document.getElementById("months");
  input.classList.remove("is-valid","is-invalid");
  input.removeAttribute("aria-invalid");
  const val=AppController.parseTermMonths();
  const match=getMatchedRange();
  if(Number.isFinite(val) && val>480){
    if(shouldShowInvalid(options)){
      input.classList.add("is-invalid");
      input.setAttribute("aria-invalid","true");
    }
    return;
  }
  if(!match || !Number.isFinite(val)){
    return;
  }
  const ok=val>=match.months[0] && val<=match.months[1];
  applyRangeValidationClass(input,ok,options);
}

function validateRateMatch(options){
  const input=document.getElementById("rate");
  input.classList.remove("is-valid","is-invalid");
  input.removeAttribute("aria-invalid");
  const match=getMatchedRange();
  if(!match || !match.rates || !match.rates.length) return;
  const raw=parseRawRateValue();
  if(!Number.isFinite(raw)) return;
  const annualRate=AppController.parseRateValue();
  if(annualRate<RATE_INPUT_MIN || annualRate>RATE_INPUT_MAX){
    if(shouldShowInvalid(options)){
      input.classList.add("is-invalid");
      input.setAttribute("aria-invalid","true");
    }
    return;
  }
  const ok=match.rates.filter(r=>r!==null).some(r=>Math.abs(annualRate-r)<0.01);
  applyRangeValidationClass(input,ok,options);
}

function validateCurrency(options){
  const select=document.getElementById("currency");
  select.classList.remove("is-valid","is-invalid");
  const prod=document.getElementById("product").value;
  const curr=normalizeCurrency(select.value);
  const prodData=PRODUCT_LIMITS[prod];
  if(!prodData){
    syncCurrencyButtons(select.value);
    return;
  }
  const ranges=prodData[curr]?.rows||[];
  const amount=AppController.parsePrincipalValue();
  if(!Number.isFinite(amount)){
    if(ranges.length) select.classList.add("is-valid");
    syncCurrencyButtons(select.value);
    return;
  }
  const ok=ranges.some(r=>amount>=r.amount[0] && (r.amount[1]===null || amount<=r.amount[1]));
  if(ok){
    select.classList.add("is-valid");
  }else if(shouldShowInvalid(options)){
    select.classList.add("is-invalid");
  }
  syncCurrencyButtons(select.value);
}

function syncCurrencyButtons(value){
  const normalized=value==="EUR" ? "EUR" : "LEK";
  document.querySelectorAll('input[name="currencyChoice"]').forEach(input=>{
    input.checked=input.value===normalized;
  });
  document.querySelectorAll(".currency-radio-group").forEach(group=>{
    group.dataset.currency=normalized;
  });
  syncPrincipalCurrencyAffix(normalized);
  return normalized;
}

function getPrincipalCurrencyCode(value){
  return value==="EUR" ? "EUR" : "ALL";
}

function syncPrincipalCurrencyAffix(value){
  const normalized=value==="EUR" ? "EUR" : "LEK";
  const code=getPrincipalCurrencyCode(normalized);
  const input=document.getElementById("principal");
  const suffix=document.getElementById("principalCurrencySuffix");
  if(input) input.placeholder=`0 ${code}`;
  if(suffix) suffix.textContent=code;
  updatePrincipalCurrencySuffixState();
}

function updatePrincipalCurrencySuffixState(){
  const input=document.getElementById("principal");
  if(!input) return;
  const entry=input.closest(".split-field-entry");
  if(!entry) return;
  const value=String(input.value||"");
  const hasValue=/\d/.test(value);
  entry.classList.toggle("has-principal-value",hasValue);
  entry.style.setProperty("--principal-value-ch",String(Math.max(value.length,1)));
}

function updateRateUnitSuffixState(){
  const input=document.getElementById("rate");
  if(!input) return;
  const entry=input.closest(".split-field-entry");
  if(!entry) return;
  const value=String(input.value||"");
  const hasValue=/\d/.test(value);
  entry.classList.toggle("has-rate-value",hasValue);
  entry.style.setProperty("--rate-value-ch",String(Math.max(value.length,1)));
}

function getCheckedRadioValue(name,fallback){
  const select=document.querySelector(`select[name="${name}"]`);
  if(select) return select.value || fallback;
  const checked=document.querySelector(`input[name="${name}"]:checked`);
  return checked ? checked.value : fallback;
}

function getRateUnit(){
  return getCheckedRadioValue("rateUnit","annual")==="monthly" ? "monthly" : "annual";
}

function getTermUnit(){
  return getCheckedRadioValue("termUnit","months")==="years" ? "years" : "months";
}

function formatUnitNumber(value){
  if(!Number.isFinite(value)) return "";
  const rounded=Math.round(value*100)/100;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2).replace(/0+$/,"").replace(/\.$/,"");
}

function parseRawRateValue(){
  const raw=document.getElementById("rate")?.value;
  const normalized=String(raw||"").replace(/,/g,".").replace(/[^0-9.]/g,"");
  const value=parseFloat(normalized);
  return Number.isFinite(value) ? value : NaN;
}

function getRateInputMax(){
  return getRateUnit()==="monthly" ? RATE_INPUT_MAX/12 : RATE_INPUT_MAX;
}

function displayRateForCurrentUnit(annualRate){
  const value=getRateUnit()==="monthly" ? annualRate/12 : annualRate;
  return formatUnitNumber(value);
}

function displayTermForCurrentUnit(months){
  const value=getTermUnit()==="years" ? months/12 : months;
  return formatUnitNumber(value);
}

function convertRateInputForUnit(previousUnit,nextUnit){
  const input=document.getElementById("rate");
  const raw=parseRawRateValue();
  if(!input || !Number.isFinite(raw) || previousUnit===nextUnit) return;
  const annualRate=previousUnit==="monthly" ? raw*12 : raw;
  input.value=nextUnit==="monthly" ? formatUnitNumber(annualRate/12) : formatUnitNumber(annualRate);
  applyRateInputLimit();
}

function convertTermInputForUnit(previousUnit,nextUnit){
  const input=document.getElementById("months");
  const raw=String(input?.value||"").replace(/,/g,".").replace(/[^0-9.]/g,"");
  const value=parseFloat(raw);
  if(!input || !Number.isFinite(value) || previousUnit===nextUnit) return;
  const months=previousUnit==="years" ? value*12 : value;
  input.value=nextUnit==="years" ? formatUnitNumber(months/12) : String(Math.round(months));
}

function syncTermInputAttributes(){
  const input=document.getElementById("months");
  if(!input) return;
  if(getTermUnit()==="years"){
    input.max="40";
    input.step="0.1";
    input.inputMode="decimal";
    input.placeholder="0 Vite";
    return;
  }
  input.max="480";
  input.step="1";
  input.inputMode="numeric";
  input.placeholder="0 Muaj";
}

let currentRateUnit="annual";
let currentTermUnit="months";

function validateDisbursementToday(){
  const input=document.getElementById("disbursement");
  if(!input) return;
  input.classList.remove("is-valid");
  const val=String(input.value||"");
  if(!val) return;
  const today=formatLocalDateForInput(new Date());
  if(val===today){
    input.classList.add("is-valid");
  }
}

function parseLoanOptionAmount(id){
  const input=document.getElementById(id);
  if(!input) return 0;
  const digits=String(input.value||"").replace(/[^0-9]/g,"");
  return digits ? Number(digits) : 0;
}

function setLoanFeeAmountMode(input,mode){
  if(!input) return;
  input.dataset.feeMode=mode==="custom" ? "custom" : "auto";
  input.classList.toggle("is-custom",input.dataset.feeMode==="custom");
}

function isLoanFeeAmountCustom(input){
  return input?.dataset.feeMode==="custom";
}

function setLoanFeeAmountReadOnly(input){
  if(!input) return;
  input.readOnly=true;
  input.tabIndex=-1;
  input.setAttribute("aria-readonly","true");
  input.title="Llogaritet automatikisht nga afati dhe perqindja e fee-se";
}

function formatLoanOptionAmountInput(input){
  if(!input) return;
  const digits=String(input.value||"").replace(/[^0-9]/g,"");
  input.value=digits ? Number(digits).toLocaleString("en-US") : "";
}

function getContractFeeRate(months){
  if(!Number.isFinite(months)) return null;
  if(months>=6 && months<=11) return 1.2;
  if(months>=12 && months<=24) return 3;
  if(months>=25 && months<=60) return 4;
  if(months>60) return 5;
  return null;
}

function formatContractFeeRate(rate){
  if(!Number.isFinite(rate)) return "";
  return Number.isInteger(rate) ? String(rate) : String(rate);
}

function normalizeLoanOptionFeeRateInput(input,options){
  if(!input) return;
  const keepTrailingDecimal=!!(options && options.keepTrailingDecimal);
  const raw=String(input.value||"").replace(/,/g,".");
  const cleaned=raw.replace(/[^0-9.]/g,"");
  const dotIndex=cleaned.indexOf(".");
  const hasDecimal=dotIndex!==-1;
  const rawInteger=hasDecimal ? cleaned.slice(0,dotIndex) : cleaned;
  const integerDigits=rawInteger.replace(/\./g,"");
  const decimalDigits=hasDecimal ? cleaned.slice(dotIndex+1).replace(/\./g,"").slice(0,2) : "";
  if(!integerDigits && !decimalDigits){
    input.value=hasDecimal && keepTrailingDecimal ? "0." : "";
    return;
  }
  const integerPart=String(parseInt(integerDigits || "0",10));
  const normalized=hasDecimal ? `${integerPart}.${decimalDigits}` : integerPart;
  const numericValue=parseFloat(normalized);
  if(!Number.isFinite(numericValue)){
    input.value="";
    return;
  }
  if(numericValue>100){
    input.value="100";
    return;
  }
  if(!hasDecimal){
    input.value=integerPart;
    return;
  }
  if(!decimalDigits){
    input.value=keepTrailingDecimal ? `${integerPart}.` : integerPart;
    return;
  }
  input.value=keepTrailingDecimal ? `${integerPart}.${decimalDigits}` : formatUnitNumber(numericValue);
}

function insertLoanFeeRateDigits(input,text){
  if(!input) return;
  const safeText=String(text||"").replace(/,/g,".").replace(/[^0-9.]/g,"");
  if(!safeText) return;
  const start=typeof input.selectionStart==="number" ? input.selectionStart : input.value.length;
  const end=typeof input.selectionEnd==="number" ? input.selectionEnd : start;
  input.setRangeText(safeText,start,end,"end");
  input.dispatchEvent(new Event("input",{bubbles:true}));
}

function parseLoanOptionFeeRate(){
  const input=document.getElementById("loanOptionFeeRate");
  const value=parseFloat(String(input?.value||"").replace(/,/g,".").replace(/[^0-9.]/g,""));
  return Number.isFinite(value) ? Math.min(Math.max(value,0),100) : NaN;
}

function setLoanFeeRateEditing(input,editing){
  if(!input) return;
  const active=!!editing;
  input.readOnly=!active;
  input.tabIndex=active ? 0 : -1;
  input.dataset.editing=active ? "true" : "false";
  input.setAttribute("aria-readonly",String(!active));
  const control=input.closest(".loan-fee-rate-control");
  if(control){
    control.classList.toggle("is-editing",active);
    control.setAttribute("aria-pressed",String(active));
  }
}

function beginLoanFeeRateEdit(input){
  if(!input) return;
  input.dataset.editValue=String(input.value||"");
  input.dataset.rateDirty="false";
  setLoanFeeRateEditing(input,true);
  window.requestAnimationFrame(()=>{
    input.focus({preventScroll:true});
    input.select();
  });
}

function finishLoanFeeRateEdit(input){
  if(!input) return;
  if(input.dataset.rateDirty==="true"){
    normalizeLoanOptionFeeRateInput(input);
  }
  delete input.dataset.editValue;
  delete input.dataset.rateDirty;
  setLoanFeeRateEditing(input,false);
  updateLoanOptionNetTotal();
}

let loanFeeRateCommitTimer=null;

function scheduleLoanFeeRateIdleCommit(input,attempt){
  window.clearTimeout(loanFeeRateCommitTimer);
  loanFeeRateCommitTimer=window.setTimeout(()=>{
    if(document.activeElement===input && (attempt||0)<3){
      scheduleLoanFeeRateIdleCommit(input,(attempt||0)+1);
      return;
    }
    if(document.activeElement===input) return;
    finishLoanFeeRateEdit(input);
  },160);
}

function updateLoanFeeLabels(rate){
  const labelText=Number.isFinite(rate) ? `Fee ${formatContractFeeRate(rate)}%` : "Fee";
  const tableLabel=document.getElementById("loanDetailFeeLabel");
  if(tableLabel) tableLabel.textContent=labelText;
}

function syncLoanOptionFeeRateInput(defaultRate){
  const input=document.getElementById("loanOptionFeeRate");
  if(!input) return Number.isFinite(defaultRate) ? defaultRate : NaN;

  const raw=String(input.value||"").trim();
  const currentRate=parseLoanOptionFeeRate();
  const previousDefault=parseFloat(input.dataset.defaultRate||"");
  const comparisonDefault=Number.isFinite(previousDefault) ? previousDefault : defaultRate;
  const isEditing=input.dataset.editing==="true";
  const hasCustomRate=raw!=="" &&
    Number.isFinite(currentRate) &&
    Number.isFinite(comparisonDefault) &&
    Math.abs(currentRate-comparisonDefault)>0.0001;

  if(isEditing && raw===""){
    input.dataset.defaultRate=Number.isFinite(defaultRate) ? String(defaultRate) : "";
    return NaN;
  }

  if(Number.isFinite(defaultRate) && (raw==="" || !hasCustomRate)){
    input.value=formatContractFeeRate(defaultRate);
  }else if(!Number.isFinite(defaultRate) && raw===""){
    input.value="";
  }

  input.dataset.defaultRate=Number.isFinite(defaultRate) ? String(defaultRate) : "";
  return parseLoanOptionFeeRate();
}

function updateLoanOptionFeeFromTerm(){
  const input=document.getElementById("loanOptionFee");
  if(!input) return;
  const principal=AppController.parsePrincipalValue();
  const months=AppController.parseTermMonths();
  const defaultRate=getContractFeeRate(months);
  const activeRate=syncLoanOptionFeeRateInput(defaultRate);
  updateLoanFeeLabels(activeRate);
  if(isLoanFeeAmountCustom(input)){
    return;
  }
  if(!Number.isFinite(principal) || principal<=0 || !Number.isFinite(activeRate)){
    input.value="";
    input.dataset.autoFee="";
    setLoanFeeAmountMode(input,"auto");
    return;
  }
  const fee=Math.round(principal*activeRate/100);
  input.value=fee.toLocaleString("en-US");
  input.dataset.autoFee=String(fee);
  setLoanFeeAmountMode(input,"auto");
}

function formatLoanDetailAmount(value){
  const currencyValue=document.getElementById("currency")?.value || "LEK";
  const currencyLabel=displayCurrencyCode(currencyValue);
  return `${Math.round(Number(value)||0).toLocaleString("en-US")} ${currencyLabel}`;
}

function setLoanDetailRow(rowId,valueId,text){
  const row=document.getElementById(rowId);
  const value=document.getElementById(valueId);
  if(!row || !value) return;
  const displayText=String(text||"").trim();
  value.textContent=displayText;
  row.classList.toggle("is-hidden",displayText==="");
}

function updateLoanPreheaderStripeRows(){
  const rows=[
    document.getElementById("loanDetailCustomerRow"),
    document.getElementById("loanDetailFeeRow"),
    document.getElementById("loanDetailActiveClosingRow"),
    document.getElementById("loanDetailNetTotalRow"),
    document.querySelector(".schedule-meta-row")
  ].filter(Boolean);

  let visibleIndex=0;
  rows.forEach(row=>{
    row.classList.remove("loan-preheader-row--stripe");
    if(row.classList.contains("is-hidden")) return;
    row.classList.toggle("loan-preheader-row--stripe",visibleIndex%2===0);
    visibleIndex+=1;
  });
}

function updateLoanDetailRows(){
  if(isSharedLoanOpen() && !window.__sharedLoanShowDetails){
    setLoanDetailRow("loanDetailCustomerRow","loanDetailCustomerValue","");
    setLoanDetailRow("loanDetailFeeRow","loanDetailFeeValue","");
    setLoanDetailRow("loanDetailActiveClosingRow","loanDetailActiveClosingValue","");
    setLoanDetailRow("loanDetailNetTotalRow","loanDetailNetTotalValue","");
    updateLoanPreheaderStripeRows();
    return;
  }

  const customerName=String(document.getElementById("loanCustomerName")?.value||"").trim();
  const feeRaw=String(document.getElementById("loanOptionFee")?.value||"").trim();
  const activeClosingRaw=String(document.getElementById("loanActiveClosing")?.value||"").trim();
  const fee=parseLoanOptionAmount("loanOptionFee");
  const activeClosing=parseLoanOptionAmount("loanActiveClosing");
  const principal=AppController.parsePrincipalValue();
  const hasNetDetail=feeRaw!=="" || activeClosingRaw!=="";
  const netTotal=Number.isFinite(principal) ? principal-fee-activeClosing : NaN;

  setLoanDetailRow("loanDetailCustomerRow","loanDetailCustomerValue",customerName);
  setLoanDetailRow("loanDetailFeeRow","loanDetailFeeValue",feeRaw!=="" ? formatLoanDetailAmount(fee) : "");
  setLoanDetailRow("loanDetailActiveClosingRow","loanDetailActiveClosingValue",activeClosingRaw!=="" ? formatLoanDetailAmount(activeClosing) : "");
  setLoanDetailRow("loanDetailNetTotalRow","loanDetailNetTotalValue",hasNetDetail && Number.isFinite(netTotal) ? formatLoanDetailAmount(netTotal) : "");
  updateLoanPreheaderStripeRows();
}

function updateLoanOptionNetTotal(){
  updateLoanOptionFeeFromTerm();
  const output=document.getElementById("loanNetTotal");
  if(!output) return;
  const principal=AppController.parsePrincipalValue();
  if(!Number.isFinite(principal)){
    output.textContent="-";
    updateLoanDetailRows();
    return;
  }
  const fee=parseLoanOptionAmount("loanOptionFee");
  const activeClosing=parseLoanOptionAmount("loanActiveClosing");
  output.textContent=Math.round(principal-fee-activeClosing).toLocaleString("en-US");
  updateLoanDetailRows();
}

function setLoanMoreOptionsOpen(open){
  const panel=document.getElementById("loanMoreOptionsPanel");
  const toggle=document.getElementById("loanMoreOptionsToggle");
  const text=document.getElementById("loanMoreOptionsToggleText");
  const mark=document.getElementById("loanMoreOptionsToggleMark");
  if(!panel || !toggle || !text || !mark) return;

  panel.hidden=!open;
  panel.classList.toggle("is-open",open);
  toggle.classList.toggle("is-open",open);
  toggle.setAttribute("aria-expanded",String(open));
  text.textContent="Details";
  mark.setAttribute("aria-hidden","true");
  if(open) updateLoanOptionNetTotal();
}

function initLoanMoreOptions(){
  const toggle=document.getElementById("loanMoreOptionsToggle");
  if(toggle){
    toggle.addEventListener("click",()=>{
      const isOpen=toggle.getAttribute("aria-expanded")==="true";
      setLoanMoreOptionsOpen(!isOpen);
    });
  }

  document.addEventListener("pointerdown",event=>{
    const label=event.target && event.target.closest ? event.target.closest("#loanMoreOptionsPanel label[for]") : null;
    if(!label) return;
    const targetInput=document.getElementById(label.getAttribute("for"));
    if(!targetInput || event.target===targetInput) return;
    event.preventDefault();
  },{capture:true,passive:false});

  document.addEventListener("click",event=>{
    const label=event.target && event.target.closest ? event.target.closest("#loanMoreOptionsPanel label[for]") : null;
    if(!label) return;
    const targetInput=document.getElementById(label.getAttribute("for"));
    if(!targetInput || event.target===targetInput) return;
    event.preventDefault();
  },{capture:true});

  const customerName=document.getElementById("loanCustomerName");
  if(customerName){
    customerName.addEventListener("input",updateLoanDetailRows);
    customerName.addEventListener("blur",updateLoanDetailRows);
  }

  const feeRate=document.getElementById("loanOptionFeeRate");
  if(feeRate){
    setLoanFeeRateEditing(feeRate,false);
    const feeRateControl=feeRate.closest(".loan-fee-rate-control");
    if(feeRateControl){
      feeRateControl.addEventListener("click",()=>{
        beginLoanFeeRateEdit(feeRate);
      });
      feeRateControl.addEventListener("keydown",event=>{
        if(event.key!=="Enter" && event.key!==" ") return;
        event.preventDefault();
        beginLoanFeeRateEdit(feeRate);
      });
    }
    feeRate.addEventListener("focus",()=>beginLoanFeeRateEdit(feeRate));
    feeRate.addEventListener("beforeinput",event=>{
      if(event.isComposing) return;
      if(typeof event.data!=="string" || event.data==="") return;
      if(!/^[0-9.,]+$/.test(event.data)){
        event.preventDefault();
        return;
      }
      if(/[.,]/.test(event.data)){
        const start=typeof feeRate.selectionStart==="number" ? feeRate.selectionStart : feeRate.value.length;
        const end=typeof feeRate.selectionEnd==="number" ? feeRate.selectionEnd : start;
        const nextValue=`${feeRate.value.slice(0,start)}${event.data}${feeRate.value.slice(end)}`;
        if((nextValue.match(/[.,]/g)||[]).length>1){
          event.preventDefault();
        }
      }
    });
    feeRate.addEventListener("paste",event=>{
      const text=event.clipboardData?.getData("text") || "";
      if(!/[^0-9.,]/.test(text) && (String(text).match(/[.,]/g)||[]).length<=1) return;
      event.preventDefault();
      feeRate.dataset.rateDirty="true";
      insertLoanFeeRateDigits(feeRate,text);
    });
    feeRate.addEventListener("input",()=>{
      feeRate.dataset.rateDirty="true";
      setLoanFeeAmountMode(document.getElementById("loanOptionFee"),"auto");
      normalizeLoanOptionFeeRateInput(feeRate,{keepTrailingDecimal:true});
      updateLoanOptionNetTotal();
      scheduleLoanFeeRateIdleCommit(feeRate);
    });
    feeRate.addEventListener("blur",()=>{
      setLoanFeeAmountMode(document.getElementById("loanOptionFee"),"auto");
      finishLoanFeeRateEdit(feeRate);
    });
    feeRate.addEventListener("keydown",event=>{
      if(event.key==="Enter"){
        event.preventDefault();
        feeRate.blur();
      }else if(event.key==="Escape"){
        event.preventDefault();
        feeRate.value=feeRate.dataset.defaultRate || feeRate.value;
        feeRate.dataset.rateDirty="false";
        feeRate.blur();
      }
    });
    document.addEventListener("pointerdown",event=>{
      if(feeRate.dataset.editing!=="true") return;
      if(feeRateControl && feeRateControl.contains(event.target)) return;
      finishLoanFeeRateEdit(feeRate);
    },{capture:true,passive:true});
  }

  const feeAmount=document.getElementById("loanOptionFee");
  if(feeAmount){
    setLoanFeeAmountReadOnly(feeAmount);
  }

  ["loanActiveClosing"].forEach(id=>{
    const input=document.getElementById(id);
    if(!input) return;
    input.addEventListener("input",()=>{
      formatLoanOptionAmountInput(input);
      updateLoanOptionNetTotal();
    });
    input.addEventListener("blur",()=>{
      formatLoanOptionAmountInput(input);
      updateLoanOptionNetTotal();
    });
  });
  updateLoanOptionNetTotal();
  updateLoanDetailRows();
}

// Final visual hint/validation layer for product fields.
function formatAmountRange(r){
  if(r.amount[1]===null) return `> ${r.amount[0].toLocaleString('en-US')}`;
  return `${r.amount[0].toLocaleString('en-US')}-${r.amount[1].toLocaleString('en-US')}`;
}

function hasProductSelected(){
  const prod=document.getElementById("product").value;
  return !!PRODUCT_LIMITS[prod];
}

function syncProductSelectVisualState(){
  const select=document.getElementById("product");
  if(!select) return;
  const selected=!!PRODUCT_LIMITS[select.value];
  select.classList.toggle("is-selected",selected);
  select.classList.toggle("is-placeholder",!selected);
}

function escapeHtml(value){
  return String(value??"")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#39;");
}

function decorateInfoLabel(html){
  return String(html).replace(/(^|<br\s*\/?>)(Info:)/g,'$1<span class="field-info-label">?</span>');
}

function hasMeaningfulHintHtml(html){
  const plain=String(html||"")
    .replace(/<br\s*\/?>/gi,"\n")
    .replace(/<[^>]*>/g,"")
    .replace(/&nbsp;/gi," ")
    .trim();
  return plain!=="" && plain!=="Info:";
}

function setHintHtml(hintId, html, options){
  const hintEl=document.getElementById(hintId);
  const isPlaceholder=!!(options && options.placeholder);
  const shouldShow=!(options && options.display===false) && (isPlaceholder || hasMeaningfulHintHtml(html));
  if(hintEl){
    hintEl.innerHTML=shouldShow ? `<span class="field-info-scroll-viewport">${decorateInfoLabel(html)}</span>` : "";
    hintEl.hidden=!shouldShow;
    hintEl.classList.toggle("is-visible",shouldShow);
    hintEl.classList.toggle("field-info--placeholder",shouldShow && isPlaceholder);
    const row=hintEl.closest(".field-row");
    if(row){
      row.classList.toggle("field-row--has-info",shouldShow);
    }
    syncAllFieldChoiceSelections();
    window.requestAnimationFrame(()=>updateInfoScrollControls(hintEl));
  }
  if(options && options.inlineId){
    const inlineEl=document.getElementById(options.inlineId);
    if(inlineEl){
      inlineEl.innerHTML=shouldShow ? decorateInfoLabel(html) : "";
    }
  }
}

function getInfoScrollTarget(hintEl){
  if(!hintEl) return null;
  return hintEl.querySelector(".field-info-scroll-viewport")
    || hintEl.querySelector(".field-choice-values")
    || hintEl.querySelector(".field-choice-strip");
}

function scrollInfoTarget(target,direction){
  if(!target) return;
  const visibleItems=Array.from(target.querySelectorAll(".field-choice-value-cell, .field-choice-item, .field-fill-choice"))
    .filter(node=>node.getBoundingClientRect().width>0);
  const firstItem=visibleItems[0];
  const step=firstItem ? firstItem.getBoundingClientRect().width+8 : Math.max(80,Math.round(target.clientWidth*0.45));
  const maxScroll=Math.max(0,target.scrollWidth-target.clientWidth);
  const nextLeft=direction<0
    ? Math.max(0,target.scrollLeft-step)
    : Math.min(maxScroll,target.scrollLeft+step);
  if(typeof target.scrollTo==="function"){
    target.scrollTo({left:nextLeft,behavior:"smooth"});
  }else{
    target.scrollLeft=nextLeft;
  }
}

function syncInfoScrollViewport(hintEl){
  if(!hintEl) return;
  const viewportWidth=document.documentElement.clientWidth || window.innerWidth || 0;
  const rect=hintEl.getBoundingClientRect();
  hintEl.style.setProperty("--field-info-viewport-offset",`${-rect.left}px`);
  hintEl.style.setProperty("--field-info-screen-inset",`${rect.left}px`);
  hintEl.style.setProperty("--field-info-viewport-width",`${viewportWidth}px`);
}

function updateInfoScrollControls(hintEl){
  if(!hintEl) return;
  syncInfoScrollViewport(hintEl);
  hintEl.querySelectorAll(".field-info-scroll-control").forEach(node=>node.remove());
  hintEl.classList.remove("field-info--scrollable");
  if(!hintEl.classList.contains("is-visible") || isMobileViewport()) return;
  const target=getInfoScrollTarget(hintEl);
  if(!target) return;
  const hasOverflow=target.scrollWidth>target.clientWidth+2;
  if(!hasOverflow) return;
  hintEl.classList.add("field-info--scrollable");
  const left=document.createElement("button");
  left.type="button";
  left.className="field-info-scroll-control field-info-scroll-control--left";
  left.setAttribute("aria-label","Leviz kapsulat majtas");
  left.innerHTML='<span aria-hidden="true"></span>';
  const right=document.createElement("button");
  right.type="button";
  right.className="field-info-scroll-control field-info-scroll-control--right";
  right.setAttribute("aria-label","Leviz kapsulat djathtas");
  right.innerHTML='<span aria-hidden="true"></span>';
  hintEl.append(left,right);
}

function fillChoiceButton(field, value, label, extraClass=""){
  return `<button type="button" class="field-fill-choice ${extraClass}" data-fill-field="${escapeHtml(field)}" data-fill-value="${escapeHtml(value)}">${escapeHtml(label)}</button>`;
}

function comparableFieldChoiceValue(field,value){
  const raw=String(value||"").trim();
  if(!raw) return "";
  if(field==="principal"){
    const num=parseFloat(raw.replace(/,/g,"").replace(/[^0-9.]/g,""));
    return Number.isFinite(num) ? String(Math.round(num)) : "";
  }
  if(field==="months"){
    const num=parseInt(raw,10);
    return Number.isFinite(num) ? String(num) : "";
  }
  if(field==="rate"){
    const num=parseFloat(raw.replace(/,/g,".").replace(/[^0-9.]/g,""));
    return Number.isFinite(num) ? num.toFixed(2) : "";
  }
  return raw;
}

function syncFieldChoiceSelection(field){
  const input=document.getElementById(field);
  const buttons=document.querySelectorAll(`.field-fill-choice[data-fill-field="${field}"]`);
  if(!input || !buttons.length) return;
  let current=comparableFieldChoiceValue(field,input.value);
  if(field==="months"){
    const months=AppController.parseTermMonths();
    current=Number.isFinite(months) ? String(months) : "";
  }
  if(field==="rate"){
    const rate=AppController.parseRateValue();
    current=Number.isFinite(rate) && rate>0 ? rate.toFixed(2) : "";
  }
  buttons.forEach(button=>{
    const choice=comparableFieldChoiceValue(field,button.getAttribute("data-fill-value"));
    button.classList.toggle("is-selected",!!current && current===choice);
  });
}

function syncAllFieldChoiceSelections(){
  ["principal","months","rate"].forEach(syncFieldChoiceSelection);
}

function renderExpandableAmountChoices(ranges, visibleCount=2){
  const shouldCollapse=ranges.length>visibleCount;
  const rendered=ranges.map((range,index)=>{
    const extraClass=shouldCollapse && index>=visibleCount ? " field-choice-range--extra" : "";
    const showRangeEnd=index<ranges.length-1 && (!shouldCollapse || index<visibleCount-1 || index>=visibleCount);
    const rangeEndClass=showRangeEnd ? " field-choice-amount-cell--range-end" : "";
    const min=range.amount[0];
    const max=range.amount[1];
    const minLabel=min.toLocaleString("en-US");
    const cells=[];
    if(max===null){
      cells.push(`<span class="field-choice-value-cell field-choice-amount-cell field-choice-amount-cell--single${rangeEndClass}${extraClass}">${fillChoiceButton("principal",min,`> ${minLabel}`)}</span>`);
    }else{
      const maxLabel=max.toLocaleString("en-US");
      cells.push(`<span class="field-choice-value-cell field-choice-amount-cell field-choice-amount-cell--range${rangeEndClass}${extraClass}"><span class="field-choice-range field-choice-amount-split">${fillChoiceButton("principal",min,minLabel,"field-fill-choice--amount-bound")}<span class="field-choice-separator">-</span>${fillChoiceButton("principal",max,maxLabel,"field-fill-choice--amount-bound")}</span></span>`);
    }
    return cells.join("");
  }).join("");
  const staticClass=shouldCollapse ? "" : " field-choice-strip--static";
  return `<span class="field-choice-strip field-choice-strip--expandable${staticClass}"><span class="field-choice-values">${rendered}</span></span>`;
}

function renderMonthsRangeChoice(months){
  const formatTermLabel=(prefix,monthsValue)=>{
    const displayValue=displayTermForCurrentUnit(monthsValue);
    if(getTermUnit()==="years"){
      const unit=displayValue==="1" ? "vit" : "vite";
      return prefix ? `${prefix}: ${displayValue} ${unit}` : `${displayValue} ${unit}`;
    }
    return prefix ? `${prefix}: ${displayValue} muaj` : `${displayValue} muaj`;
  };
  const choices=[
    { value:months[0], label:formatTermLabel("Min",months[0]) },
    { value:12, label:formatTermLabel("",12) },
    { value:24, label:formatTermLabel("",24) },
    { value:months[1], label:formatTermLabel("Max",months[1]) }
  ].filter((choice,index,list)=>{
    if(choice.value<months[0] || choice.value>months[1]) return false;
    return list.findIndex(item=>item.value===choice.value)===index;
  });
  const buttons=choices.map(choice=>fillChoiceButton("months",choice.value,choice.label)).join("");
  return `<span class="field-choice-range field-choice-range--spaced">${buttons}</span>`;
}

function joinFieldChoices(items){
  return items.join('<span class="field-choice-list-separator">;</span>');
}

function renderClickableRates(text){
  return escapeHtml(text).replace(/([A-Za-zÇËçë. ]*?)\s*(\d+(?:\.\d{1,2})?)%/g,(match,label,value)=>{
    const cleanLabel=String(label||"").replace(/\s+/g," ").trim();
    const displayValue=displayRateForCurrentUnit(parseFloat(value));
    const unitSuffix=getRateUnit()==="monthly" ? "% mujore" : "%";
    const buttonLabel=cleanLabel ? `${cleanLabel} ${displayValue}${unitSuffix}` : `${displayValue}${unitSuffix}`;
    return fillChoiceButton("rate",value,buttonLabel,"field-fill-choice--rate");
  });
}

function applyFieldFillChoice(button){
  const field=button.getAttribute("data-fill-field");
  const rawValue=button.getAttribute("data-fill-value");
  const input=document.getElementById(field);
  if(!input || rawValue===null) return;

  button.classList.add("is-tapped");
  window.setTimeout(()=>button.classList.remove("is-tapped"),180);

  if(field==="rate"){
    const annualRate=parseFloat(String(rawValue).replace(/,/g,".").replace(/[^0-9.]/g,""));
    input.value=Number.isFinite(annualRate) ? displayRateForCurrentUnit(annualRate) : rawValue;
  }else if(field==="months"){
    const months=parseFloat(String(rawValue).replace(/,/g,".").replace(/[^0-9.]/g,""));
    input.value=Number.isFinite(months) ? displayTermForCurrentUnit(months) : rawValue;
  }else{
    input.value=rawValue;
  }
  input.dispatchEvent(new Event("input",{bubbles:true}));
  input.dispatchEvent(new Event("change",{bubbles:true}));

  if(field==="principal"){
    AppController.formatPrincipalInput();
  }
  if(field==="rate"){
    applyRateInputLimit();
  }
  syncFieldChoiceSelection(field);
}

function isMobileViewport(){
  if(document.body && document.body.classList.contains("credit-page")) return true;
  return window.matchMedia("(max-width: 768px)").matches;
}

function getFieldScrollTarget(element){
  if(!element || typeof element.closest!=="function") return element;
  return element.closest(".field-row") || element.closest(".split-field") || element;
}

let mobileFocusScrollTimer=null;

function isLockedMobileShellScroll(){
  return window.matchMedia("(max-width: 1199px)").matches &&
    document.body &&
    !document.body.classList.contains("shared-loan-view") &&
    (
      document.body.classList.contains("mobile-top-shell-active")
    );
}

function shouldFreezeMobileShellHeader(){
  return isLockedMobileShellScroll();
}

function resetWindowScrollForFrozenHeader(){
  if(!shouldFreezeMobileShellHeader()) return;
  if(isLoanDetailsFocusTarget(document.activeElement)) return;
  if(window.scrollY!==0 || window.pageYOffset!==0){
    window.scrollTo(0,0);
  }
}

function isLoanDetailsFocusTarget(element){
  return !!(
    element &&
    typeof element.closest==="function" &&
    element.closest("#loanMoreOptionsPanel")
  );
}

function syncLoanDetailsFocusClass(element){
  if(!document.body) return;
  document.body.classList.toggle("details-input-focus",isLoanDetailsFocusTarget(element));
}

function readRootPixelVariable(name){
  const root=document.documentElement;
  if(!root) return 0;
  const value=getComputedStyle(root).getPropertyValue(name);
  return Math.max(0, parseFloat(value) || 0);
}

function getActiveMobileHeaderHeight(){
  if(!document.body) return 0;
  if(document.body.classList.contains("mobile-top-shell-active")){
    return readRootPixelVariable("--mobile-top-shell-header-safe-height");
  }
  return 0;
}

function getMobileScrollContainer(){
  if(document.body && document.body.classList.contains("shared-loan-view")){
    return document.scrollingElement || document.documentElement;
  }
  if(
    window.matchMedia("(max-width: 1199px)").matches &&
    document.body &&
    document.body.classList.contains("mobile-top-shell-active")
  ){
    return document.querySelector(".credit-wrap");
  }
  return document.scrollingElement || document.documentElement;
}

function scrollActiveFieldIntoView(element, behavior){
  if(!element || !isMobileViewport()) return;
  if(shouldFreezeMobileShellHeader()){
    resetWindowScrollForFrozenHeader();
    return;
  }

  const target=getFieldScrollTarget(element);
  const scrollContainer=getMobileScrollContainer();
  if(!target || !scrollContainer) return;

  window.clearTimeout(mobileFocusScrollTimer);
  mobileFocusScrollTimer=window.setTimeout(()=>{
    const targetRect=target.getBoundingClientRect();
    const containerRect=scrollContainer===document.scrollingElement || scrollContainer===document.documentElement
      ? {top:0,bottom:window.innerHeight}
      : scrollContainer.getBoundingClientRect();

    const headerHeight=getActiveMobileHeaderHeight();
    const topInset=headerHeight ? Math.max(16, Math.round(headerHeight) + 12) : 16;

    const keyboardInsetRaw=getComputedStyle(document.documentElement).getPropertyValue("--mobile-keyboard-inset");
    const keyboardInset=Math.max(0, parseFloat(keyboardInsetRaw) || 0);
    const visibleTop=containerRect.top + (scrollContainer===document.scrollingElement || scrollContainer===document.documentElement ? topInset : 12);
    const visibleBottom=containerRect.bottom - Math.max(20, keyboardInset + 12);

    let delta=0;
    if(targetRect.bottom > visibleBottom){
      delta=targetRect.bottom - visibleBottom;
    }else if(targetRect.top < visibleTop){
      delta=targetRect.top - visibleTop;
    }

    if(Math.abs(delta) < 4) return;

    if(scrollContainer===document.scrollingElement || scrollContainer===document.documentElement){
      window.scrollTo({
        top:Math.max(0, window.scrollY + delta),
        behavior:behavior || "smooth"
      });
      return;
    }

    scrollContainer.scrollTo({
      top:Math.max(0, scrollContainer.scrollTop + delta),
      behavior:behavior || "smooth"
    });
  },90);
}

function updateMobileKeyboardInset(){
  const root=document.documentElement;
  if(!root) return;

  if(!isMobileViewport()){
    root.style.setProperty("--mobile-keyboard-inset","0px");
    document.body.classList.remove("keyboard-open");
    return;
  }

  let inset=0;
  if(window.visualViewport){
    inset=Math.max(
      0,
      Math.round(window.innerHeight - window.visualViewport.height - window.visualViewport.offsetTop)
    );
  }

  root.style.setProperty("--mobile-keyboard-inset",`${inset}px`);
  const isKeyboardOpen=inset>120;
  document.body.classList.toggle("keyboard-open",isKeyboardOpen);
}

function isLockedShellTextEntry(element){
  if(!element || typeof element.matches!=="function") return false;
  if(!element.matches("input, textarea")) return false;
  if(element.disabled || element.readOnly) return false;
  const type=(element.getAttribute("type") || "text").toLowerCase();
  return ![
    "button",
    "checkbox",
    "color",
    "date",
    "datetime-local",
    "file",
    "hidden",
    "image",
    "month",
    "radio",
    "range",
    "reset",
    "submit",
    "time",
    "week"
  ].includes(type);
}

let lockedShellInputTap=null;

function rememberLockedShellInputTap(event){
  if(!isLockedMobileShellScroll()) return;
  const target=event.target && event.target.closest ? event.target.closest("input, textarea") : null;
  if(!isLockedShellTextEntry(target)) return;
  if(target.closest(".mobile-top-shell__header")) return;

  lockedShellInputTap={
    pointerId:event.pointerId,
    target,
    startX:event.clientX,
    startY:event.clientY,
    moved:false
  };
}

function updateLockedShellInputTap(event){
  const state=lockedShellInputTap;
  if(!state || state.pointerId!==event.pointerId) return;
  if(Math.hypot(event.clientX-state.startX,event.clientY-state.startY)>8){
    state.moved=true;
  }
}

function cancelLockedShellInputTap(event){
  const state=lockedShellInputTap;
  if(!state || state.pointerId!==event.pointerId) return;
  lockedShellInputTap=null;
}

function focusLockedShellInputWithoutPageScroll(event){
  const state=lockedShellInputTap;
  if(!state || state.pointerId!==event.pointerId){
    return;
  }
  lockedShellInputTap=null;
  if(state.moved) return;

  const target=state.target;
  if(!isLockedMobileShellScroll() || !isLockedShellTextEntry(target)) return;

  const scrollContainer=getMobileScrollContainer();
  const containerScrollTop=scrollContainer ? scrollContainer.scrollTop : 0;
  const windowScrollTop=window.scrollY || window.pageYOffset || 0;

  event.preventDefault();
  target.focus({preventScroll:true});

  if(scrollContainer && scrollContainer.scrollTop!==containerScrollTop){
    scrollContainer.scrollTop=containerScrollTop;
  }
  if(!isLoanDetailsFocusTarget(target) && (windowScrollTop!==0 || window.scrollY!==0 || window.pageYOffset!==0)){
    window.scrollTo(0,0);
  }
  window.requestAnimationFrame(()=>{
    if(scrollContainer && scrollContainer.scrollTop!==containerScrollTop){
      scrollContainer.scrollTop=containerScrollTop;
    }
    if(!isLoanDetailsFocusTarget(target)){
      resetWindowScrollForFrozenHeader();
    }
  });
}

function setupFrozenMobileHeaderGuard(){
  resetWindowScrollForFrozenHeader();
  document.addEventListener("pointerdown",rememberLockedShellInputTap,{capture:true,passive:true});
  document.addEventListener("pointermove",updateLockedShellInputTap,{capture:true,passive:true});
  document.addEventListener("pointerup",focusLockedShellInputWithoutPageScroll,{capture:true,passive:false});
  document.addEventListener("pointercancel",cancelLockedShellInputTap,{capture:true,passive:true});
  window.addEventListener("scroll",resetWindowScrollForFrozenHeader,{passive:true});
  document.addEventListener("focusin",event=>{
    syncLoanDetailsFocusClass(event.target);
    if(isLoanDetailsFocusTarget(event.target)) return;
    window.requestAnimationFrame(resetWindowScrollForFrozenHeader);
    window.setTimeout(resetWindowScrollForFrozenHeader,80);
    window.setTimeout(resetWindowScrollForFrozenHeader,260);
  });
  document.addEventListener("touchmove",event=>{
    if(!isLockedMobileShellScroll()) return;
    if(event.target && event.target.closest(".mobile-top-shell__header")){
      event.preventDefault();
    }
  },{passive:false});
}

function setupMobileKeyboardAssist(){
  updateMobileKeyboardInset();
  resetWindowScrollForFrozenHeader();

  document.addEventListener("focusin",event=>{
    const target=event.target;
    if(!target || !isMobileViewport()) return;
    syncLoanDetailsFocusClass(target);
    if(!(target.matches("input, select, textarea") || target.closest(".currency-seg .seg-btn"))) return;
    updateMobileKeyboardInset();
    if(!isLoanDetailsFocusTarget(target)){
      resetWindowScrollForFrozenHeader();
    }
    if(!shouldFreezeMobileShellHeader()){
      scrollActiveFieldIntoView(target,"smooth");
    }
  });

  document.addEventListener("focusout",()=>{
    window.setTimeout(()=>{
      const active=document.activeElement;
      syncLoanDetailsFocusClass(active);
      if(!active || active===document.body){
        document.documentElement.style.setProperty("--mobile-keyboard-inset","0px");
        document.body.classList.remove("keyboard-open");
      }
    },180);
  });

  if(window.visualViewport){
    const syncViewport=()=>{
      updateMobileKeyboardInset();
      const active=document.activeElement;
      if(!isLoanDetailsFocusTarget(active)){
        resetWindowScrollForFrozenHeader();
      }
      if(
        active &&
        !isLoanDetailsFocusTarget(active) &&
        !shouldFreezeMobileShellHeader() &&
        (active.matches("input, select, textarea") || active.closest(".currency-seg .seg-btn"))
      ){
        scrollActiveFieldIntoView(active,"auto");
      }
    };
    window.visualViewport.addEventListener("resize",syncViewport);
    window.visualViewport.addEventListener("scroll",syncViewport);
  }

  window.addEventListener("orientationchange",()=>window.setTimeout(()=>{
    updateMobileKeyboardInset();
    resetWindowScrollForFrozenHeader();
  },250));
  window.addEventListener("resize",()=>{
    updateMobileKeyboardInset();
    resetWindowScrollForFrozenHeader();
    document.querySelectorAll(".field-info.is-visible").forEach(updateInfoScrollControls);
  });
}

function updatePrincipalHint(){
  if(!hasProductSelected()){
    setHintHtml("principalHint","",{display:false});
    return;
  }
  const ranges=getRangesForSelection();
  if(ranges.length){
    const productValue=document.getElementById("product").value;
    const list = productValue.includes("KREDI \"PER GRATE\"")
      ? Array.from(new Map(ranges.map(range=>[formatAmountRange(range),range])).values())
      : ranges;
    setHintHtml("principalHint",renderExpandableAmountChoices(list,2));
    if(window.lucide && typeof window.lucide.createIcons==="function"){
      window.lucide.createIcons();
    }
  }else{
    setHintHtml("principalHint","",{display:false});
  }
}

function updateMonthsHint(){
  if(!hasProductSelected()){
    setHintHtml("monthsHint","",{display:false});
    return;
  }
  if(!hasPrincipalEntry()){
    setHintHtml("monthsHint","",{display:false});
    return;
  }
  const match=getMatchedRange();
  if(!match){
    setHintHtml("monthsHint","",{display:false});
    return;
  }
  setHintHtml("monthsHint",renderMonthsRangeChoice(match.months));
}

function prettyRateLabel(label){
  const up=String(label||"").toUpperCase();
  if(up.includes("HIPOTEK")) return "Hip.";
  if(up==="RBS") return "RBS";
  if(up.includes("PA KOLATERAL")) return "Pa Kol.";
  if(up.includes("PA KOL")) return "Pa Kol.";
  if(up.includes("VETEPUNES")) return "Vetepunesuar";
  if(up.includes("LICENS")) return "Licensuar";
  if(up.includes("ME GARANTOR")) return "Me garant";
  if(up.includes("PA GARANTOR")) return "Pa garant";
  return String(label||"").trim();
}

function joinInfoSegments(parts){
  return parts.join(" ");
}

function resolveGroupLabel(product, labels, match){
  const upperLabels=labels.map(l=>String(l||"").toUpperCase());
  if(upperLabels.some(l=>l.includes("VETEPUNES"))) return "Vetepunesuar";
  if(upperLabels.some(l=>l.includes("LICENS"))) return "Licensuar";
  if(upperLabels.some(l=>l.includes("PA KOLATERAL"))) return "Pa kolateral";
  if(upperLabels.some(l=>l.includes("PA KOL"))) return "Pa kolateral";

  if(product.includes("KREDI \"PER GRATE\"")){
    const ranges=getRangesForSelection();
    const idx=ranges.indexOf(match);
    if(idx===0) return "Vetepunesuar";
    if(idx===1) return "Licensuar";
    return "Vetepunesuar";
  }

  if(product.includes("KREDI KONSUMATORE") || product.includes("KREDI PERSONALE")){
    return "Pa kolateral";
  }

  return "";
}

function buildRateInfo(match, overrideGroupLabel){
  const labels=getRateLabels();
  const entries=(match.rates||[])
    .map((r,i)=>({rate:r,label:labels[i]||""}))
    .filter(e=>e.rate!==null && e.rate!==undefined);
  if(!entries.length) return "";

  let meGarant=null;
  let paGarant=null;
  let paKolLabel=null;
  const base=[];
  const productValue=document.getElementById("product").value;

  for(const e of entries){
    const up=String(e.label||"").toUpperCase();
    if(up.includes("ME GARANTOR")){
      meGarant=e.rate;
      continue;
    }
    if(up.includes("PA GARANTOR")){
      paGarant=e.rate;
      continue;
    }
    if(up.includes("PA KOL")){
      paKolLabel=prettyRateLabel(e.label);
      base.push({label:paKolLabel, rate:e.rate, isPaKol:true});
      continue;
    }
    base.push({label:prettyRateLabel(e.label), rate:e.rate});
  }

  if(!paKolLabel && (meGarant!==null || paGarant!==null)){
    const resolved=overrideGroupLabel || resolveGroupLabel(productValue, labels, match);
    if(resolved) paKolLabel=resolved;
  }

  const groupPaKol=paKolLabel && (meGarant!==null || paGarant!==null);
  const parts=[];

  base.filter(b=>!(b.isPaKol && groupPaKol)).forEach(b=>{
    parts.push(`${b.label} ${b.rate.toFixed(2)}%`);
  });

  if(groupPaKol){
    if(meGarant!==null) parts.push(`Me garant ${meGarant.toFixed(2)}%`);
    if(paGarant!==null) parts.push(`Pa garant ${paGarant.toFixed(2)}%`);
  }else{
    if(meGarant!==null) parts.push(`Me garant ${meGarant.toFixed(2)}%`);
    if(paGarant!==null) parts.push(`Pa garant ${paGarant.toFixed(2)}%`);
  }

  return joinInfoSegments(parts);
}

function updateRateHint(){
  if(!hasProductSelected()){
    setHintHtml("rateHint","",{display:false});
    return;
  }
  if(!hasPrincipalEntry()){
    setHintHtml("rateHint","",{display:false});
    return;
  }
  const match=getMatchedRange();
  const productValue=document.getElementById("product").value;
  if(productValue.includes("KREDI \"PER GRATE\"")){
    const ranges=getRangesForSelection();
    const amount=AppController.parsePrincipalValue();
    if(Number.isFinite(amount)){
      const primary=ranges.find(r=>amount>=r.amount[0] && (r.amount[1]===null || amount<=r.amount[1]));
      if(primary){
        const group=ranges.filter(r=>r.amount[0]===primary.amount[0] && r.amount[1]===primary.amount[1]);
        if(group.length){
          const segments=[];
          const labels=["VETEPUNESUAR","LICENSUAR"];
          group.slice(0,2).forEach((m,idx)=>{
            const info=buildRateInfo(m, labels[idx]);
            if(info) segments.push(info);
          });
          if(segments.length){
            setHintHtml("rateHint",joinFieldChoices(segments.map(renderClickableRates)));
            return;
          }
        }
      }
    }
  }

  if(match && match.rates && match.rates.length){
    const info=buildRateInfo(match);
    if(info){
      setHintHtml("rateHint",renderClickableRates(info));
      return;
    }
  }
  setHintHtml("rateHint","",{display:false});
}

function updateValidationBadges(){
  const pairs=[
    {inputId:"principal", badgeId:"principalValidBadge"},
    {inputId:"rate", badgeId:"rateValidBadge"},
    {inputId:"months", badgeId:"monthsValidBadge"}
  ];
  pairs.forEach(({inputId,badgeId})=>{
    const input=document.getElementById(inputId);
    const badge=document.getElementById(badgeId);
    if(!input || !badge) return;
    badge.classList.toggle("is-visible",input.classList.contains("is-valid"));
    const shell=input.closest(".split-field--principal");
    if(shell){
      shell.classList.toggle("is-valid",input.classList.contains("is-valid"));
      shell.classList.toggle("is-invalid",input.classList.contains("is-invalid"));
    }
    const row=input.closest(".field-row");
    if(row){
      row.classList.toggle("is-valid",input.classList.contains("is-valid"));
      row.classList.toggle("is-invalid",input.classList.contains("is-invalid"));
    }
  });
}

function updateScheduleProduct(){
  const el=document.getElementById("scheduleProduct");
  if(!el) return;
  const prod=document.getElementById("product").value;
  el.textContent=PRODUCT_LIMITS[prod] ? prod : "-";
}


function validateProductMatch(options){
  const select=document.getElementById("product");
  select.classList.remove("is-valid","is-invalid");
  if(!PRODUCT_LIMITS[select.value]){
    return;
  }

  const principalEl=document.getElementById("principal");
  const monthsEl=document.getElementById("months");
  const rateEl=document.getElementById("rate");
  const currencyEl=document.getElementById("currency");

  const hasPrincipal=String(principalEl.value||"").trim()!=="";
  const hasMonths=String(monthsEl.value||"").trim()!=="";
  const hasRate=String(rateEl.value||"").trim()!=="";
  const hasCurrency=String(currencyEl.value||"").trim()!=="";

  const anyFilled=hasPrincipal || hasMonths || hasRate || hasCurrency;
  if(!anyFilled){
    return;
  }

  const amountOk=principalEl.classList.contains("is-valid");
  const monthsOk=monthsEl.classList.contains("is-valid");
  const rateOk=rateEl.classList.contains("is-valid");
  const currencyOk=currencyEl.classList.contains("is-valid");

  const allFilled=hasPrincipal && hasMonths && hasRate && hasCurrency;
  if(allFilled){
    if(amountOk && monthsOk && rateOk && currencyOk){
      select.classList.add("is-valid");
    }else if(shouldShowInvalid(options)){
      select.classList.add("is-invalid");
    }
    return;
  }

  const anyInvalid=principalEl.classList.contains("is-invalid") ||
    monthsEl.classList.contains("is-invalid") ||
    rateEl.classList.contains("is-invalid") ||
    currencyEl.classList.contains("is-invalid");
  if(anyInvalid && shouldShowInvalid(options)){
    select.classList.add("is-invalid");
  }
}

