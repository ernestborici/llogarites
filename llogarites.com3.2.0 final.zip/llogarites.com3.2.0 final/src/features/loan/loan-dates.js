/* ======================================================
   DATE RULES
====================================================== */

const HOLIDAYS=new Set(["01-01","14-03","22-03","12-04","01-05","05-09","22-11","28-11","29-11","08-12","25-12"]);

function atLocalNoon(y,m,d){return new Date(y,m,d,12,0,0,0);}
function isHoliday(d){let day=String(d.getDate()).padStart(2,'0');let month=String(d.getMonth()+1).padStart(2,'0');return HOLIDAYS.has(`${day}-${month}`);}
function isWeekend(d){return d.getDay()===0||d.getDay()===6;}
function adjustToBusinessDay(date){let d=atLocalNoon(date.getFullYear(),date.getMonth(),date.getDate());while(isWeekend(d)||isHoliday(d)){d.setDate(d.getDate()+1);d=atLocalNoon(d.getFullYear(),d.getMonth(),d.getDate());}return d;}
function getLastDayOfMonth(y,m){return new Date(y,m+1,0).getDate();}
function getInstallmentDate(disb,i,firstPaymentDate){
let anchor=isValidLocalDate(firstPaymentDate) ? firstPaymentDate : null;
if(anchor){
if(i===1) return adjustToBusinessDay(anchor);
let y=anchor.getFullYear();
let m=anchor.getMonth()+i-1;
let d=anchor.getDate();
let base=atLocalNoon(y,m,1);
let last=getLastDayOfMonth(base.getFullYear(),base.getMonth());
if(d>last)d=last;
let date=atLocalNoon(base.getFullYear(),base.getMonth(),d);
return adjustToBusinessDay(date);
}
let y=disb.getFullYear();let m=disb.getMonth()+i;let d=disb.getDate();let base=atLocalNoon(y,m,1);let last=getLastDayOfMonth(base.getFullYear(),base.getMonth());if(d>last)d=last;let date=atLocalNoon(base.getFullYear(),base.getMonth(),d);return adjustToBusinessDay(date);}
function formatInputDate(value){
  if(!value) return "-";
  const m=String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m) return `${m[3]}/${m[2]}/${m[1]}`;
  return value;
}

function parseLocalDate(value){
  const m=String(value||"").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(!m) return new Date(value);
  return atLocalNoon(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

function formatLocalDateForInput(date){
  const y=date.getFullYear();
  const m=String(date.getMonth()+1).padStart(2,'0');
  const d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

const FIRST_PAYMENT_DATE_WINDOW_DAYS=10;

function isValidLocalDate(date){
  return date instanceof Date && Number.isFinite(date.getTime());
}

function addCalendarDays(date,days){
  return atLocalNoon(date.getFullYear(),date.getMonth(),date.getDate()+days);
}

function getFirstPaymentDate(disb){
  if(!isValidLocalDate(disb)) return null;
  const base=atLocalNoon(disb.getFullYear(),disb.getMonth()+1,1);
  const day=Math.min(disb.getDate(),getLastDayOfMonth(base.getFullYear(),base.getMonth()));
  return atLocalNoon(base.getFullYear(),base.getMonth(),day);
}

function isCustomFirstPaymentDate(disb,firstPaymentValue){
  const autoDate=getFirstPaymentDate(disb);
  if(!isValidLocalDate(autoDate)) return false;
  return String(firstPaymentValue||"").trim()!==formatLocalDateForInput(autoDate);
}

function updateDateInputEmptyState(input){
  if(!input) return;
  input.classList.toggle("is-empty",!String(input.value||"").trim());
}

function updateFirstPaymentDateBounds(baseDate){
  const firstPayment=document.getElementById("firstPaymentDate");
  if(!firstPayment || !isValidLocalDate(baseDate)){
    if(firstPayment){
      firstPayment.removeAttribute("min");
      firstPayment.removeAttribute("max");
    }
    return {base:null,min:null,max:null};
  }
  const min=addCalendarDays(baseDate,-FIRST_PAYMENT_DATE_WINDOW_DAYS);
  const max=addCalendarDays(baseDate,FIRST_PAYMENT_DATE_WINDOW_DAYS);
  firstPayment.min=formatLocalDateForInput(min);
  firstPayment.max=formatLocalDateForInput(max);
  return {base:baseDate,min,max};
}

function validateFirstPaymentDate(){
  const disbursement=document.getElementById("disbursement");
  const firstPayment=document.getElementById("firstPaymentDate");
  const notice=document.getElementById("firstPaymentDateNotice");
  const card=document.querySelector(".loan-more-date-card");
  updateDateInputEmptyState(disbursement);
  updateDateInputEmptyState(firstPayment);
  if(!disbursement || !firstPayment) return true;

  const disbRaw=String(disbursement.value||"").trim();
  const baseDate=disbRaw ? getFirstPaymentDate(parseLocalDate(disbRaw)) : null;
  const bounds=updateFirstPaymentDateBounds(baseDate);
  let valid=true;
  let message="";

  if(!String(firstPayment.value||"").trim()){
    valid=false;
    message="Vendos daten e pare te pageses brenda intervalit +/-10 dite nga data e disbursimit.";
  }else{
    const selected=parseLocalDate(firstPayment.value);
    if(!isValidLocalDate(selected)){
      valid=false;
      message="Data e pare e pageses nuk eshte e vlefshme.";
    }else if(bounds.min && bounds.max && (selected<bounds.min || selected>bounds.max)){
      valid=false;
      const minText=formatInputDate(formatLocalDateForInput(bounds.min));
      const maxText=formatInputDate(formatLocalDateForInput(bounds.max));
      message=`Data e pare e pageses lejohet te ndryshohet vetem ne intervalin +/-10 dite nga data e disbursimit: ${minText} deri ${maxText}.`;
    }
  }

  firstPayment.setAttribute("aria-invalid",String(!valid));
  if(notice){
    firstPayment.setAttribute("aria-describedby",notice.id);
    notice.textContent=message;
    notice.hidden=valid || !message;
  }
  if(card) card.classList.toggle("is-invalid",!valid);
  return valid;
}

function syncFirstPaymentDateFromDisbursement(){
  const disbursement=document.getElementById("disbursement");
  const firstPayment=document.getElementById("firstPaymentDate");
  if(!disbursement || !firstPayment) return;
  const raw=String(disbursement.value||"").trim();
  if(!raw){
    firstPayment.value="";
    validateFirstPaymentDate();
    return;
  }
  const nextDate=getFirstPaymentDate(parseLocalDate(raw));
  firstPayment.value=nextDate ? formatLocalDateForInput(nextDate) : "";
  validateFirstPaymentDate();
}
