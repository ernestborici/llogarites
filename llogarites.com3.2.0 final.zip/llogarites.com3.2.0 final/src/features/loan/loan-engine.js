/* ======================================================
   CORE FINANCIAL ENGINE - MOS E EDITO
====================================================== */

const LoanEngine=(function(){

function formatDate(d){
return String(d.getDate()).padStart(2,'0')+"/"+String(d.getMonth()+1).padStart(2,'0')+"/"+d.getFullYear();
}

function daysInYear(date){
let y=date.getFullYear();
return((y%4===0&&y%100!==0)||(y%400===0))?366:365;
}

function diffDays(d1,d2){
const utc1=Date.UTC(d1.getFullYear(),d1.getMonth(),d1.getDate());
const utc2=Date.UTC(d2.getFullYear(),d2.getMonth(),d2.getDate());
return Math.round((utc2-utc1)/(1000*60*60*24));
}

function roundValue(value,currency,type){
if(currency==="EUR") return Math.round(value*10)/10;
if(currency==="LEK"){
if(type==="installment") return Math.ceil(value/100)*100;
return Math.round(value/100)*100;
}
}

function calculatePMT(P,r,n){
if(r===0) return P/n;
return(P*r)/(1-Math.pow(1+r,-n));
}

function generateSchedule(params){
let{P,n,annualRate,currency,disb,firstPaymentDate}=params;
let r=annualRate/12;
let PMT=roundValue(calculatePMT(P,r,n),currency,"installment");
let balance=P;
let prevDate=disb;
let rows=[];
let totals={inst:0,int:0,prin:0};
for(let i=1;i<=n;i++){
let payDate=getInstallmentDate(disb,i,firstPaymentDate);
let days=diffDays(prevDate,payDate);
let interest=roundValue((days/daysInYear(prevDate))*annualRate*balance,currency,"other");
let installment=PMT;
if(i===n||balance+interest<PMT) installment=balance+interest;
installment=roundValue(installment,currency,"installment");
let principal=roundValue(installment-interest,currency,"other");
if(principal>balance){
principal=balance;
installment=roundValue(principal+interest,currency,"installment");
}
balance=roundValue(balance-principal,currency,"other");
if(balance<0) balance=0;
totals.inst+=installment;
totals.int+=interest;
totals.prin+=principal;
rows.push({nr:i,date:formatDate(payDate),installment,interest,principal,balance});
prevDate=payDate;
if(balance<=0) break;
}
return{rows,totals};
}
return{generateSchedule};
})();

