function loanAmountBand(value){
  if(!Number.isFinite(value) || value<=0) return "unknown";
  if(value<=100000) return "0-100k";
  if(value<=500000) return "100k-500k";
  if(value<=1000000) return "500k-1m";
  if(value<=5000000) return "1m-5m";
  return "5m+";
}

function loanRateBand(value){
  if(!Number.isFinite(value) || value<0) return "unknown";
  if(value<=5) return "0-5";
  if(value<=10) return "5-10";
  if(value<=20) return "10-20";
  if(value<=50) return "20-50";
  return "50+";
}

function loanMonthsBand(value){
  if(!Number.isFinite(value) || value<=0) return "unknown";
  if(value<=12) return "0-12";
  if(value<=36) return "13-36";
  if(value<=60) return "37-60";
  if(value<=120) return "61-120";
  return "120+";
}

function loanAnalyticsTracker(){
  try{
    if(window.parent && window.parent !== window && window.parent.LlogaritesAnalytics){
      return window.parent.LlogaritesAnalytics;
    }
  }catch(_){}
  return window.LlogaritesAnalytics || null;
}

function trackLoanEvent(name, params){
  const analytics=loanAnalyticsTracker();
  if(!analytics || typeof analytics.trackEvent!=="function" || !name) return;
  analytics.trackEvent(name, params || {});
}

const loanAnalyticsState={
  lastCalculationKey:"",
  lastTableKey:""
};

let loanResultsVisible=false;
let loanUserInteracted=false;

function setResultsVisible(visible){
  loanResultsVisible=!!visible;
  if(document.body){
    document.body.classList.toggle("loan-results-visible", loanResultsVisible);
  }
  const panel=document.getElementById("resultsPanel");
  const surface=document.getElementById("loanResultsSurface");
  if(panel){
    panel.classList.toggle("is-hidden",!loanResultsVisible);
  }
  if(surface){
    surface.classList.toggle("is-hidden",!loanResultsVisible);
  }
}

function revealResultsPanel(behavior){
  const panel=document.getElementById("resultsPanel");
  if(!panel || panel.classList.contains("is-hidden")) return;
  const surface=document.getElementById("loanResultsSurface") || panel;
  const actions=document.querySelector(".credit-actions");
  const scrollContainer=(typeof getMobileScrollContainer==="function")
    ? getMobileScrollContainer()
    : (document.scrollingElement || document.documentElement);
  if(!actions || !scrollContainer){
    surface.scrollIntoView({
      block:"start",
      inline:"nearest",
      behavior:behavior || "smooth"
    });
    return;
  }

  const scrollingRoot=scrollContainer===document.scrollingElement || scrollContainer===document.documentElement;
  const containerRect=scrollingRoot
    ? { top:0, bottom:window.innerHeight }
    : scrollContainer.getBoundingClientRect();
  const headerOffset=16;
  const currentScrollTop=scrollingRoot ? window.scrollY : scrollContainer.scrollTop;
  const actionsRect=actions.getBoundingClientRect();
  const panelRect=surface.getBoundingClientRect();
  const targetTop=currentScrollTop + (actionsRect.top - containerRect.top) - headerOffset;
  const shouldAdjust=panelRect.top > (containerRect.bottom - 80) || actionsRect.top < (containerRect.top + headerOffset);

  if(!shouldAdjust) return;

  const nextTop=Math.max(0, Math.round(targetTop));
  if(scrollingRoot){
    window.scrollTo({ top:nextTop, behavior:behavior || "smooth" });
    return;
  }

  scrollContainer.scrollTo({ top:nextTop, behavior:behavior || "smooth" });
}

const PRINCIPAL_INPUT_MAX=999999999;

function isSharedLoanOpen(){
const params=new URLSearchParams(window.location.search);
return !!(params.get("s") || window.location.pathname.match(/\/s\/([A-Za-z0-9]+)\/?$/));
}

function resetLoanVisualState(){
["product","principal","months","rate","currency"].forEach(id=>{
const el=document.getElementById(id);
if(!el) return;
el.classList.remove("is-valid","is-invalid");
});
document.querySelectorAll(".split-field--principal").forEach(node=>{
node.classList.remove("is-valid","is-invalid");
});
["principalHint","monthsHint","rateHint"].forEach(id=>{
const el=document.getElementById(id);
if(el) el.innerHTML="";
});
const schedule=document.getElementById("schedule");
if(schedule) schedule.innerHTML="";
setResultsVisible(false);
}

function applyFreshOpenState(){
if(isSharedLoanOpen() || loanUserInteracted) return;
AppController.resetFreshOpenFields();
syncProductSelectVisualState();
const disbursement=document.getElementById("disbursement");
if(disbursement) disbursement.value=formatLocalDateForInput(new Date());
resetLoanVisualState();
syncFirstPaymentDateFromDisbursement();
validateDisbursementToday();
AppController.updateDisplay();
AppController.updatePrintMeta();
AppController.updateLoanMeta();
updateScheduleProduct();
updatePrincipalHint();
updateMonthsHint();
updateRateHint();
if(window.scrollY>0){
window.scrollTo(0,0);
}
}

function scheduleFreshOpenState(){
if(isSharedLoanOpen()) return;
[0,80,240,700,1400,2500].forEach(delay=>{
window.setTimeout(applyFreshOpenState,delay);
});
window.addEventListener("pageshow",()=>{
window.setTimeout(applyFreshOpenState,0);
window.setTimeout(applyFreshOpenState,180);
});
}

/* ======================================================
   UI + WhatsApp Short Link
====================================================== */

const AppController={
init(){
this.resetFreshOpenFields();
currentRateUnit=getRateUnit();
currentTermUnit=getTermUnit();
syncTermInputAttributes();
applyRateInputLimit();
let today=new Date();
document.getElementById("disbursement").value=formatLocalDateForInput(today);
syncFirstPaymentDateFromDisbursement();
validateDisbursementToday();
this.updateDisplay();
  this.updatePrintMeta();
   this.updateLoanMeta();
  setResultsVisible(false);
  this.checkURL();
  updateScheduleProduct();
  updatePrincipalHint();
  validatePrincipalRange();
  updateMonthsHint();
  validateMonthsRange();
  updateRateHint();
validateRateMatch();
validateCurrency();
validateProductMatch();
},
resetFreshOpenFields(){
if(isSharedLoanOpen()) return;
const fields={
  product:"Zgjidh Produktin",
  principal:"",
  months:"",
  rate:"",
  currency:"LEK"
};
Object.entries(fields).forEach(([id,value])=>{
  const el=document.getElementById(id);
  if(el) el.value=value;
});
},
parseRateValue(){
let raw=document.getElementById("rate").value;
let normalized=String(raw).replace(/,/g,".").replace(/[^0-9.]/g,"");
let value=parseFloat(normalized);
if(!Number.isFinite(value)) return 0;
const annualValue=getRateUnit()==="monthly" ? value*12 : value;
return Math.min(annualValue,RATE_INPUT_MAX);
},
parseTermMonths(){
const input=document.getElementById("months");
let raw=String(input?.value||"").replace(/,/g,".").replace(/[^0-9.]/g,"");
let value=parseFloat(raw);
if(!Number.isFinite(value)) return NaN;
const months=getTermUnit()==="years" ? value*12 : value;
return Math.round(months);
},
  parsePrincipalValue(){
  let raw=document.getElementById("principal").value;
  let normalized=String(raw).replace(/,/g,"").replace(/[^0-9]/g,"");
  if(!normalized) return NaN;
  return Math.min(parseFloat(normalized),PRINCIPAL_INPUT_MAX);
  },
formatPrincipalInput(){
const input=document.getElementById("principal");
const digits=String(input.value).replace(/[^0-9]/g,"");
 if(!digits){
 input.value="";
 return;
 }
 const capped=Math.min(Number(digits),PRINCIPAL_INPUT_MAX);
 input.value=Number.isFinite(capped) ? capped.toLocaleString("en-US") : "";
},
updatePrintMeta(){
let now=new Date();
const text=now.toLocaleString('en-GB',{
  day:'2-digit',
  month:'2-digit',
  year:'numeric',
  hour:'2-digit',
  minute:'2-digit',
  hour12:false
});
document.getElementById("printDateTime").innerText=text;
},
updateLoanMeta(){
  const meta=document.getElementById("loanMeta");
  if(!meta) return;
  const amount=AppController.parsePrincipalValue();
  const amountRaw=String(document.getElementById("principal").value||"").trim();
  const monthsRaw=String(document.getElementById("months").value||"").trim();
  const rateRaw=String(document.getElementById("rate").value||"").trim();
  const disbRaw=String(document.getElementById("disbursement").value||"").trim();

  const amountText=Number.isFinite(amount) ? amount.toLocaleString("en-US") : (amountRaw || "-");
  const monthsVal=AppController.parseTermMonths();
  const termUnit=getTermUnit()==="years" ? "vite" : "muaj";
  const monthsText=Number.isFinite(monthsVal) ? `${monthsRaw || monthsVal} ${termUnit}` : (monthsRaw || "-");
  const rateVal=AppController.parseRateValue();
  const rateUnit=getRateUnit()==="monthly" ? "% mujore" : "% vjetore";
  const rateText=rateRaw!=="" && Number.isFinite(rateVal) ? `${rateRaw} ${rateUnit}` : (rateRaw || "-");
  const dateText=formatInputDate(disbRaw);

  meta.textContent=`/ ${amountText} / ${monthsText} / ${rateText} / ${dateText} /`;
},
updateDisplay(){
return;
},
calculate(options){
const tracking=Object.assign({
  trackCalculation:false,
  trackTableView:false,
  source:"interactive",
  revealResults:true
}, options || {});
this.updatePrintMeta();
this.updateLoanMeta();
if(typeof updateLoanDetailRows==="function") updateLoanDetailRows();
let P=this.parsePrincipalValue();
let n=this.parseTermMonths();
let r=this.parseRateValue();
let isFirstPaymentValid=validateFirstPaymentDate();

if(!isFirstPaymentValid || !Number.isFinite(P) || !Number.isFinite(n) || !Number.isFinite(r) || P<=0 || n<=0){
document.getElementById("schedule").innerHTML="";
setResultsVisible(false);
return;
}

const disbDate=parseLocalDate(document.getElementById("disbursement").value);
const firstPaymentRaw=String(document.getElementById("firstPaymentDate")?.value||"").trim();
const firstPaymentDate=parseLocalDate(firstPaymentRaw);
const useCustomFirstPayment=isValidLocalDate(disbDate) &&
  isValidLocalDate(firstPaymentDate) &&
  isCustomFirstPaymentDate(disbDate,firstPaymentRaw);

let params={
P:P,
n:n,
annualRate:r/100,
currency:document.getElementById("currency").value,
disb:disbDate,
firstPaymentDate:useCustomFirstPayment ? firstPaymentDate : null
};
let schedule=LoanEngine.generateSchedule(params);
this.render(schedule,params.currency);
setResultsVisible(true);
if(tracking.revealResults!==false && tracking.source!=="shared_link"){
  window.requestAnimationFrame(()=>revealResultsPanel("smooth"));
}
const product=document.getElementById("product").value || "unknown";
const eventKey=[
  product,
  params.currency,
  P,
  n,
  Number(r).toFixed(2)
].join("|");
const analyticsPayload={
  product,
  currency:params.currency || "unknown",
  amount_band:loanAmountBand(P),
  months_band:loanMonthsBand(n),
  rate_band:loanRateBand(r)
};
if(tracking.trackCalculation && loanAnalyticsState.lastCalculationKey!==eventKey){
  trackLoanEvent("loan_calculation_completed", analyticsPayload);
  loanAnalyticsState.lastCalculationKey=eventKey;
}
if(tracking.trackTableView && loanAnalyticsState.lastTableKey!==eventKey){
  trackLoanEvent("amortization_table_viewed", Object.assign({
    source:tracking.source || "interactive"
  }, analyticsPayload));
  loanAnalyticsState.lastTableKey=eventKey;
}
this.updatePrintMeta();
},
render(schedule,currency){
const totalCurrencyLabel=typeof displayCurrencyCode==="function"
  ? displayCurrencyCode(currency)
  : (normalizeCurrency(currency)==="EURO" ? "EUR" : "ALL");
const renderTotalAmount=(value)=>`<span class="schedule-total-amount"><span class="schedule-total-amount__value">${value.toLocaleString('en-US')}</span><span class="schedule-total-amount__currency">${totalCurrencyLabel}</span></span>`;
let html=`
<tr class="schedule-total-row">
<td colspan="2" class="cell-center">TOTAL</td>
<td>${renderTotalAmount(schedule.totals.inst)}</td>
<td>${renderTotalAmount(schedule.totals.prin)}</td>
<td>${renderTotalAmount(schedule.totals.int)}</td>
<td>-</td>
</tr>`;
schedule.rows.forEach((r,i)=>{
let zebra=i%2===0?"schedule-row schedule-row--alt":"schedule-row";
html+=`<tr class="${zebra}">
<td class="cell-center">${r.nr}</td>
<td class="cell-center">${r.date}</td>
<td>${r.installment.toLocaleString('en-US')}</td>
<td>${r.principal.toLocaleString('en-US')}</td>
<td>${r.interest.toLocaleString('en-US')}</td>
<td>${r.balance.toLocaleString('en-US')}</td>
</tr>`;});
document.getElementById("schedule").innerHTML=html;
},
print(){
if(document.getElementById("schedule").innerHTML.trim()===""){
this.calculate();
}else{
this.updatePrintMeta();
}
trackLoanEvent("loan_print",{
  content_type:"loan_schedule",
  product:document.getElementById("product").value || "unknown",
  currency:document.getElementById("currency").value || "unknown"
});
window.print();
},
checkURL(){
let params=new URLSearchParams(window.location.search);
const pathMatch=window.location.pathname.match(/\/s\/([A-Za-z0-9]+)\/?$/);
const sharedCode=params.get("s") || (pathMatch ? pathMatch[1] : "");
if(sharedCode){
let decoded=decodeSharedLoan(sharedCode);
if(decoded && decoded.P>0 && decoded.n>0 && decoded.rate>0){
document.getElementById("principal").value=decoded.P;
document.getElementById("months").value=decoded.n;
document.getElementById("rate").value=decoded.rate;
document.getElementById("product").value=decoded.prod;
document.getElementById("currency").value=decoded.curr||"LEK";
const sharedDetails=typeof getSharedLoanDetailsFromUrl==="function" ? getSharedLoanDetailsFromUrl() : null;
if(typeof applySharedLoanDetails==="function") applySharedLoanDetails(sharedDetails);
applyRateInputLimit();
    this.formatPrincipalInput();
syncCurrencyButtons(document.getElementById("currency").value);
syncProductSelectVisualState();
updateScheduleProduct();
document.body.classList.add("shared-loan-view");
trackLoanEvent("shared_link_opened",{
  share_type:"short_link",
  product:decoded.prod || "unknown",
  currency:decoded.curr || "LEK"
});
    this.calculate({ trackTableView:true, source:"shared_link", revealResults:false });
return;
}
}
}
};

