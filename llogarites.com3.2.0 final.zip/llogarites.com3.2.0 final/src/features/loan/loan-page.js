/* ======================================================
   INIT
====================================================== */

function hideLoanResults(){
  document.getElementById("schedule").innerHTML="";
  setResultsVisible(false);
}

let autoCalculateTimer=null;
function scheduleAutoCalculate(){
  window.clearTimeout(autoCalculateTimer);
  autoCalculateTimer=window.setTimeout(()=>{
    AppController.calculate({
      source:"auto",
      revealResults:false
    });
  },180);
}

document.getElementById("disbursement")
.addEventListener("change",()=>{
  syncFirstPaymentDateFromDisbursement();
  validateDisbursementToday();
  AppController.updateDisplay();
  AppController.updateLoanMeta();
});

const FIELD_CHOICE_SWIPE_CANCEL_PX=8;
let fieldChoicePointerState=null;

function suppressFieldChoiceClick(button){
  if(!button) return;
  button.__llogaritesSuppressClickUntil=Date.now()+450;
}

function isFieldChoiceClickSuppressed(button){
  return !!(button && button.__llogaritesSuppressClickUntil && button.__llogaritesSuppressClickUntil>Date.now());
}

document.addEventListener("pointerdown",event=>{
  const button=event.target && event.target.closest(".field-fill-choice");
  const dragSurface=event.target && event.target.closest(".field-info-scroll-viewport, .field-choice-values, .field-choice-strip");
  if(!button && !dragSurface) return;
  if(typeof event.button==="number" && event.button>0) return;
  const hintEl=(button || dragSurface).closest(".field-info");
  const scrollTarget=(typeof getInfoScrollTarget==="function" ? getInfoScrollTarget(hintEl) : null) || dragSurface;
  fieldChoicePointerState={
    pointerId:event.pointerId,
    button,
    scrollTarget,
    startX:event.clientX,
    startY:event.clientY,
    startScrollLeft:scrollTarget ? scrollTarget.scrollLeft : 0,
    canScroll:!!(scrollTarget && scrollTarget.scrollWidth>scrollTarget.clientWidth+2),
    moved:false
  };
  if(button) button.__llogaritesPointerApplied=false;
},{passive:true});

document.addEventListener("pointermove",event=>{
  const state=fieldChoicePointerState;
  if(!state || state.pointerId!==event.pointerId) return;
  const dx=event.clientX-state.startX;
  const dy=event.clientY-state.startY;
  if(Math.hypot(dx,dy)>FIELD_CHOICE_SWIPE_CANCEL_PX){
    state.moved=true;
    suppressFieldChoiceClick(state.button);
  }
  if(state.canScroll && state.moved && Math.abs(dx)>Math.abs(dy)){
    event.preventDefault();
    state.scrollTarget.scrollLeft=state.startScrollLeft-dx;
  }
},{passive:false});

document.addEventListener("pointerup",event=>{
  const state=fieldChoicePointerState;
  if(!state || state.pointerId!==event.pointerId) return;
  const button=state.button;
  fieldChoicePointerState=null;
  if(state.moved){
    suppressFieldChoiceClick(button);
    return;
  }
  if(!button) return;
  event.preventDefault();
  button.__llogaritesPointerApplied=true;
  applyFieldFillChoice(button);
  window.setTimeout(()=>{
    button.__llogaritesPointerApplied=false;
  },350);
},{passive:false});

document.addEventListener("pointercancel",event=>{
  const state=fieldChoicePointerState;
  if(!state || state.pointerId!==event.pointerId) return;
  suppressFieldChoiceClick(state.button);
  fieldChoicePointerState=null;
},{passive:true});

document.addEventListener("click",event=>{
  const scrollButton=event.target && event.target.closest(".field-info-scroll-control");
  if(scrollButton){
    event.preventDefault();
    const hintEl=scrollButton.closest(".field-info");
    const target=getInfoScrollTarget(hintEl);
    scrollInfoTarget(target,scrollButton.classList.contains("field-info-scroll-control--left") ? -1 : 1);
    return;
  }
  const button=event.target && event.target.closest(".field-fill-choice");
  if(!button) return;
  event.preventDefault();
  if(isFieldChoiceClickSuppressed(button)) return;
  if(button.__llogaritesPointerApplied) return;
  applyFieldFillChoice(button);
});

AppController.init();
initLoanMoreOptions();
scheduleFreshOpenState();
setupMobileKeyboardAssist();
setupFrozenMobileHeaderGuard();
applyRateInputLimit();
updatePrincipalHint();
updateMonthsHint();
updateRateHint();
updateValidationBadges();
syncCurrencyButtons(document.getElementById("currency").value);
syncProductSelectVisualState();

const shareLoanButton=document.getElementById("shareLoanButton");
if(shareLoanButton){
  shareLoanButton.addEventListener("click",shareWhatsApp);
}

["principal","months","rate"].forEach(id=>{
const el=document.getElementById(id);
if(!el) return;
if(!isMobileViewport()){
  el.addEventListener("focus",()=>el.select());
  el.addEventListener("click",()=>el.select());
}
});

["principal","months","rate","product","currency","disbursement","firstPaymentDate"].forEach(id=>{
const el=document.getElementById(id);
if(!el) return;
const markInteraction=()=>{ loanUserInteracted=true; };
el.addEventListener("pointerdown",markInteraction,{passive:true});
el.addEventListener("keydown",markInteraction);
el.addEventListener("input",()=>{
  hideLoanResults();
  scheduleAutoCalculate();
});
el.addEventListener("change",()=>{
  hideLoanResults();
  scheduleAutoCalculate();
});
});

["loanCustomerName","loanOptionFeeRate","loanOptionFee","loanActiveClosing"].forEach(id=>{
const el=document.getElementById(id);
if(!el) return;
const markInteraction=()=>{ loanUserInteracted=true; };
el.addEventListener("pointerdown",markInteraction,{passive:true});
el.addEventListener("keydown",markInteraction);
el.addEventListener("input",markInteraction);
el.addEventListener("change",markInteraction);
});

["disbursement"].forEach(id=>{
  const el=document.getElementById(id);
  if(!el) return;
  el.addEventListener("input",()=>{
    syncFirstPaymentDateFromDisbursement();
    validateDisbursementToday();
    AppController.updateLoanMeta();
  });
});

["firstPaymentDate"].forEach(id=>{
  const el=document.getElementById(id);
  if(!el) return;
  const validate=()=>{
    validateFirstPaymentDate();
    AppController.updateLoanMeta();
  };
  el.addEventListener("input",validate);
  el.addEventListener("change",validate);
});

function validateProductInputs(options){
  validatePrincipalRange(options);
  validateMonthsRange(options);
  validateRateMatch(options);
  validateCurrency(options);
  validateProductMatch(options);
  updateValidationBadges();
}

function commitProductInputValidation(inputId){
  if(inputId==="principal"){
    validatePrincipalRange();
    updateMonthsHint();
    validateMonthsRange();
    updateRateHint();
    validateRateMatch();
    validateCurrency();
    validateProductMatch();
  }else if(inputId==="months"){
    validateMonthsRange();
    validateProductMatch();
  }else if(inputId==="rate"){
    applyRateInputLimit();
    validateRateMatch();
    validateProductMatch();
  }
  updateValidationBadges();
}

document.getElementById("product").addEventListener("change",()=>{
  loanUserInteracted=true;
  syncProductSelectVisualState();
  updateScheduleProduct();
  updatePrincipalHint();
  updateMonthsHint();
  updateRateHint();
  validateProductInputs();
});
document.getElementById("principal").addEventListener("input",()=>{
  AppController.formatPrincipalInput();
  if(typeof updatePrincipalCurrencySuffixState==="function") updatePrincipalCurrencySuffixState();
  updateLoanOptionNetTotal();
  validatePrincipalRange({showInvalid:false});
  syncFieldChoiceSelection("principal");
  updateMonthsHint();
  validateMonthsRange({showInvalid:false});
  updateRateHint();
  validateRateMatch({showInvalid:false});
  validateCurrency({showInvalid:false});
  validateProductMatch({showInvalid:false});
  AppController.updateLoanMeta();
  updateValidationBadges();
});
document.getElementById("months").addEventListener("input",()=>{
  const input=document.getElementById("months");
  if(input.value!==""){
    let v=parseFloat(String(input.value).replace(/,/g,"."));
    if(Number.isFinite(v)){
      if(v<1){
        input.value="";
      }else{
        const maxValue=getTermUnit()==="years" ? 40 : 480;
        if(v>maxValue){
          input.value=maxValue;
        }
      }
    }
  }
  validateMonthsRange({showInvalid:false});
  syncFieldChoiceSelection("months");
  validateProductMatch({showInvalid:false});
  updateLoanOptionNetTotal();
  AppController.updateLoanMeta();
  updateValidationBadges();
});
document.getElementById("rate").addEventListener("input",()=>{
  applyRateInputLimit();
  validateRateMatch({showInvalid:false});
  syncFieldChoiceSelection("rate");
  validateProductMatch({showInvalid:false});
  AppController.updateLoanMeta();
  updateValidationBadges();
});
["principal","months","rate"].forEach(inputId=>{
  const input=document.getElementById(inputId);
  if(!input) return;
  input.addEventListener("blur",()=>{
    commitProductInputValidation(inputId);
  });
  input.addEventListener("keydown",(event)=>{
    if(event.key!=="Enter") return;
    event.preventDefault();
    commitProductInputValidation(inputId);
    input.blur();
  });
});
document.getElementById("currency").addEventListener("change",()=>{
  syncCurrencyButtons(document.getElementById("currency").value);
  updateLoanOptionNetTotal();
  updatePrincipalHint();
  updateMonthsHint();
  updateRateHint();
  validateProductInputs();
});

document.querySelectorAll('input[name="currencyChoice"]').forEach(input=>{
  input.addEventListener("change",()=>{
    if(!input.checked) return;
    const select=document.getElementById("currency");
    if(!select) return;
    select.value=input.value==="EUR" ? "EUR" : "LEK";
    select.dispatchEvent(new Event("change",{bubbles:true}));
  });
});

document.querySelectorAll('select[name="rateUnit"], input[name="rateUnit"]').forEach(input=>{
  input.addEventListener("change",()=>{
    if(input.type==="radio" && !input.checked) return;
    const nextUnit=getRateUnit();
    convertRateInputForUnit(currentRateUnit,nextUnit);
    currentRateUnit=nextUnit;
    applyRateInputLimit();
    updateRateHint();
    validateRateMatch();
    syncFieldChoiceSelection("rate");
    validateProductMatch();
    AppController.updateLoanMeta();
    updateValidationBadges();
    hideLoanResults();
    scheduleAutoCalculate();
  });
});

document.querySelectorAll('select[name="termUnit"], input[name="termUnit"]').forEach(input=>{
  input.addEventListener("change",()=>{
    if(input.type==="radio" && !input.checked) return;
    const nextUnit=getTermUnit();
    convertTermInputForUnit(currentTermUnit,nextUnit);
    currentTermUnit=nextUnit;
    syncTermInputAttributes();
    updateMonthsHint();
    validateMonthsRange();
    syncFieldChoiceSelection("months");
    validateProductMatch();
    updateLoanOptionNetTotal();
    AppController.updateLoanMeta();
    updateValidationBadges();
    hideLoanResults();
    scheduleAutoCalculate();
  });
});

[
  {inputId:"principal", buttonId:"principalClear"},
  {inputId:"rate", buttonId:"rateClear"},
  {inputId:"months", buttonId:"monthsClear"}
].forEach(({inputId,buttonId})=>{
  const input=document.getElementById(inputId);
  const button=document.getElementById(buttonId);
  if(!input || !button) return;
  button.addEventListener("click",()=>{
    input.value="";
    input.dispatchEvent(new Event("input",{bubbles:true}));
    input.dispatchEvent(new Event("change",{bubbles:true}));
    input.focus();
  });
});

document.addEventListener('DOMContentLoaded',()=>{ if(window.lucide){ lucide.createIcons(); }});
